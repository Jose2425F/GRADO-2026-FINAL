"""Fallo de restauración inducido en el banco propio; sin API ni terceros."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import sys
import time

BASE=Path(__file__).resolve().parent
REPO=BASE.parent/'GRADO-2026-FINAL'
sys.path[:0]=[str(REPO/'scripts'),str(REPO/'piloto_kali/prototipo/src')]
from auditoria import empresa_agent as engine,lab_empresa as bank
from auditoria.store import RunStore,write_json
from tesis.orquestacion_langgraph import LangGraphOrchestrator
from tesis.protocolo_ipv6 import instrument_protocol
from tesis.segmentos import SegmentGuard,SegmentQuarantined,DEFAULT_ROOT


def main():
    out=BASE/'fallo-real-11-1-v2'
    if out.exists():raise SystemExit('No sobrescribir un ensayo previo')
    bank.load_auditor_environment(REPO/'piloto_kali/prototipo/.lab-empresa')
    before=bank.preflight(REPO/'piloto_kali/prototipo/.lab-empresa')
    req=engine.request('LAB-PROPIO',llm=False,tokens=0)
    catalog=engine.build_plan(req)
    tasks=[t for t in catalog if t.target.asset_id=='receiver_a' and any(p in t.action_profile for p in ['slaac','ra_route'])]
    tasks+=[t for t in catalog if t.target.asset_id=='receiver_b' and 'slaac' in t.action_profile]
    store=RunStore(out,req.audit_id);guard=SegmentGuard(DEFAULT_ROOT,store)
    write_json(out/'request.json',req.model_dump(mode='json'))
    write_json(out/'plan.json',[t.model_dump(mode='json') for t in tasks])
    write_json(out/'preflight.json',before)
    dispatched=[];reset=bank.reset_receiver;fault=[];results={};recovery=None
    def fail_reset(receiver):
        if receiver==bank.RECEIVERS['receiver_a']:
            fault.append('reset_after_real_ra_probe')
            raise RuntimeError('injected_restoration_failure_20261109')
        return reset(receiver)
    def execute(task):
        dispatched.append(task.task_id)
        return engine.run_task(task,store)
    controller=LangGraphOrchestrator(tasks=tasks,workers=2,deadline=time.monotonic()+600,
        store=store,prepare=lambda:None,execute=execute,terminal=lambda t,r:r,
        close=lambda c:None,segments=guard,
        authorize=lambda t:engine.authorize_empresa(req,engine.policy(),task=t))
    try:
        bank.reset_receiver=fail_reset
        with instrument_protocol(engine,bank,on_restored=guard.restored):controller.invoke()
        results={k:v.model_dump(mode='json') for k,v in controller.completed.items()}
        peer=tasks[-1]
        independent=SegmentGuard(DEFAULT_ROOT)
        try:
            independent.acquire(peer)
        except SegmentQuarantined:durable=True
        else:
            independent.release(peer)
            raise AssertionError('quarantine_not_durable')
        assert len(fault)==1
        assert results[peer.task_id]['reason_code']=='segment_quarantined'
        assert peer.task_id not in dispatched
        write_json(out/'failure-results.json',{'fault_injection':fault,'dispatched':dispatched,
            'results':results,'new_controller_denied':durable})
    finally:
        bank.reset_receiver=reset
        # Recover only the two owned receivers while holding the segment lock.
        def recover():
            return {name:reset(receiver) for name,receiver in bank.RECEIVERS.items()}
        try:
            recovery=SegmentGuard(DEFAULT_ROOT,store).recover(['br-nova-dc'],recover)
            write_json(out/'recovery.json',recovery)
        finally:store.close()
    check=RunStore(out/'after-recovery','recovered')
    final_guard=SegmentGuard(DEFAULT_ROOT,check)
    try:
        peer=tasks[-1];final_guard.acquire(peer)
        with instrument_protocol(engine,bank,on_restored=final_guard.restored):result=engine.run_task(peer,check)
        final_guard.release(peer)
        assert result.status.value=='completed'
        write_json(out/'after-recovery/result.json',result.model_dump(mode='json'))
    finally:check.close()
    with sqlite3.connect(out/'events.sqlite3') as db:
        events=[r[0] for r in db.execute('select kind from events')]
    summary={'date':datetime.now(timezone.utc).isoformat(),'scope':'owned_integrated_bank',
        'actual_ra_probe':True,'fault':'restoration callback intentionally raises before reset',
        'receiver_b_blocked':True,'quarantine_survived_new_controller':True,
        'verified_recovery':bool(recovery),'receiver_b_slaac_after_recovery':'completed',
        'api_calls':0,'event_kinds':sorted(set(events))}
    write_json(out/'summary.json',summary);print(json.dumps(summary))

if __name__=='__main__':main()
