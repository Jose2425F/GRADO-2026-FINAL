"""Observación pasiva de procesos de una aceptación propia; sin guardar argv."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'GRADO-2026-FINAL'
FIELDS={'Uid','Gid','CapInh','CapPrm','CapEff','CapBnd','CapAmb','NoNewPrivs','Seccomp'}
command=[sys.executable,str(REPO/'scripts/laboratorio_empresa.py'),'--job',str(HERE/'aceptacion-actual-job.json'),
         '--output',str(HERE/'aceptacion-final-20261109')]
seen={};started=datetime.now(timezone.utc).isoformat()
with (HERE/'aceptacion-final.log').open('x') as stream:
    process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,cwd=REPO)
    deadline=time.monotonic()+900
    while process.poll() is None and time.monotonic()<deadline:
        for path in Path('/proc').iterdir():
            if not path.name.isdigit():continue
            try:
                args=(path/'cmdline').read_bytes().split(b'\0')
                if not args:continue
                role=None
                if int(path.name)==process.pid:role='controller_and_inprocess_adapters'
                elif args[0].split(b'/')[-1] in {b'nmap',b'hydra'}:
                    if any(x.startswith(b'192.168.71.') for x in args):role=args[0].split(b'/')[-1].decode()
                elif b'/app/datacenter/sender.py' in args and any(x.startswith(b'fd57:2026:70::') for x in args):role='ipv6_sender'
                if role is None:continue
                status={k:v.strip() for line in (path/'status').read_text().splitlines() if ':' in line
                        for k,v in [line.split(':',1)] if k in FIELDS}
                key=(path.name,(path/'stat').read_text().split()[21])
                seen.setdefault(key,{'pid':int(path.name),'role':role,'observed_at':datetime.now(timezone.utc).isoformat(),
                                     'status':status,'net_namespace':os.readlink(path/'ns/net')})
            except (OSError,ValueError,IndexError):continue
        time.sleep(.05)
    if process.poll() is None:
        sys.path.insert(0,str(REPO/'scripts'))
        from tesis.procesos import terminate_group
        terminate_group(process,grace_seconds=5)
    rc=process.wait(timeout=5)
out={'started_at':started,'ended_at':datetime.now(timezone.utc).isoformat(),'audit_returncode':rc,
     'method':'passive_proc_sampling_50ms','processes':list(seen.values()),
     'limits':['Sampling can miss short-lived processes.','No minimum-privilege claim follows from this receipt.',
               'In-process HTTP and corroboration adapters share controller privileges.'],
     'command_arguments_and_environment_saved':False}
(HERE/'privilegios-efectivos-20261109.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'returncode':rc,'roles':sorted({x['role'] for x in seen.values()}),'processes':len(seen)}))
