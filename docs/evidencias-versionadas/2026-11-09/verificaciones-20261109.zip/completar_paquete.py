"""Conserva copias privadas, sin alterar las fuentes ni publicar artefactos."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
OUT = HERE / 'paquete-privado'
BASE = HERE.parent


def copy(source, destination):
    if source.is_dir():
        shutil.copytree(source, destination, dirs_exist_ok=True)
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)


for name in ['aceptacion-real-20261109', 'aceptacion-final-20261109',
             'fallo-real-11-1', 'fallo-real-11-1-v2', 'diagnostico-11-1', 'wheels',
             'informes-aceptacion-20261109', 'referencias-primarias']:
    copy(HERE / name, OUT / 'revision-20261109' / name)

for source in HERE.iterdir():
    if source.is_file() and source.suffix in {'.json', '.txt', '.xml', '.log', '.py'}:
        if source.name not in {'informe-extraido.txt', 'informe-estructura.json',
                               'propuesta-recuperada-drive.txt'}:
            copy(source, OUT / 'revision-20261109' / source.name)

historical = BASE / 'publicacion-evidencias-20261018/docs/evidencias-historicas/2026-10-18'
copy(historical, OUT / 'historico-20261018')
copy(BASE / 'revision-respaldo-drive/soportes-recuperados/soportes-academicos',
     OUT / 'soportes-academicos-recuperados')
copy(BASE / 'revision-respaldo-drive/soportes-recuperados/docs/evaluacion-langgraph',
     OUT / 'revision-respaldo-drive/soportes-recuperados/docs/evaluacion-langgraph')
copy(HERE / 'TrabajoDeGrado_II_Revisado_20261109.docx',
     OUT / 'TrabajoDeGrado_II_Revisado_20261109.docx')

for source in OUT.rglob('*'):
    source.chmod(0o700 if source.is_dir() else 0o600)
OUT.chmod(0o700)
print(json.dumps({'files': sum(p.is_file() for p in OUT.rglob('*')),
                  'path': str(OUT)}, ensure_ascii=False))
