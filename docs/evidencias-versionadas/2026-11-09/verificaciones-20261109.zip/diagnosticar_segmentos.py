"""Diagnóstico del controlador con el catálogo real y herramientas simuladas."""
from pathlib import Path
import hashlib
import json
import sqlite3
import sys
import threading
import time

REPO = Path('/home/kali/Documents/Codex/2026-11-07/cone/work/GRADO-2026-FINAL')
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(REPO / 'scripts'), str(REPO / 'piloto_kali/prototipo/src')]
from auditoria import empresa_agent
from auditoria.contracts import TaskResult
from auditoria.store import RunStore
from tesis.orquestacion_langgraph import LangGraphOrchestrator, TaskExecutionError


def diagnostic(name, inject_failure=False):
    directory = HERE / 'diagnostico-11-1' / name
    if directory.exists():
        raise RuntimeError('El diagnóstico ya existe; no sobrescribir sus registros.')
    request = empresa_agent.request('LAB-PROPIO', llm=False, tokens=0)
    tasks = empresa_agent.build_plan(request)
    store = RunStore(directory, request.audit_id)
    calls, results, active = [], [], []
    mutex = threading.Lock()
    failure_seen = threading.Event()
    first_pair_started = threading.Event()
    peak = 0
    protocol_overlap = False

    def simulated_tool(task):
        nonlocal peak, protocol_overlap
        with mutex:
            is_ipv6 = task.agent_type in {'ipv6_ndp', 'ipv6_fragmentation'}
            protocol_overlap |= is_ipv6 and any(t.agent_type in {'ipv6_ndp', 'ipv6_fragmentation'} for t in active)
            active.append(task)
            calls.append({'task_id': task.task_id, 'asset': task.target.asset_id,
                          'interface': task.target.interface, 'profile': task.action_profile,
                          'started_after_restoration_failure': failure_seen.is_set()})
            first = len(calls) == 1
            peak = max(peak, len(active))
            if len(active) == 2:
                first_pair_started.set()
        try:
            if first and not first_pair_started.wait(timeout=5):
                raise RuntimeError('No se observó concurrencia en tareas independientes.')
            if inject_failure and task.target.asset_id == 'receiver_a' and task.action_profile == 'ipv6_ra_route_v2':
                failure_seen.set()
                raise TaskExecutionError(stage='ipv6_restore', reason_code='ipv6_restore_failed')
            time.sleep(0.002)
            return TaskResult(task_id=task.task_id, status='completed_no_findings',
                              observations={'simulated_tool': True, 'restored': True})
        finally:
            with mutex:
                active.remove(task)

    def terminal(task, result):
        results.append(result.model_dump(mode='json'))
        return result

    controller = LangGraphOrchestrator(
        tasks=tasks, workers=2, deadline=time.monotonic() + 300, reserve_seconds=1,
        store=store, prepare=lambda: None, execute=simulated_tool,
        terminal=terminal, close=lambda controller: None,
        authorize=lambda task: empresa_agent.authorize_empresa(request, empresa_agent.policy(), task=task))
    try:
        controller.invoke()
    finally:
        store.close()
    with sqlite3.connect(directory / 'events.sqlite3') as connection:
        events = [{'kind': kind, 'task_id': task, 'payload': json.loads(payload)}
                  for kind, task, payload in connection.execute(
                      'SELECT kind,task_id,payload_json FROM events ORDER BY rowid')]
    explicit_segment_events = [e for e in events if 'segment' in e['kind']]
    after_failure = [c for c in calls if c['started_after_restoration_failure'] and c['interface'] == 'br-nova-dc']
    result = {
        'scope': 'Simulación del controlador, sin herramientas de red, proveedor LLM ni auditorías reales.',
        'catalogue_tasks': len(tasks), 'simulated_calls': calls, 'results': results,
        'maximum_concurrent_tasks': peak, 'ipv6_tasks_overlapped': protocol_overlap,
        'explicit_segment_lock_events': len(explicit_segment_events),
        'restoration_failure_injected': inject_failure,
        'same_segment_calls_after_failure': after_failure,
        'rf08_explicit_segment_lock_demonstrated': bool(explicit_segment_events),
        'rf26_failure_quarantine_demonstrated': not after_failure if inject_failure else None,
        'events': events,
    }
    (directory / 'diagnostico.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    return result


normal = diagnostic('concurrencia')
failure = diagnostic('fallo-restauracion', inject_failure=True)
summary = {
    'date_utc': '2026-11-09',
    'status': 'Brechas reproducidas; todavía no corregidas.',
    'scope': 'Diagnóstico aislado del controlador con catálogo y autorización reales, herramientas simuladas y cero llamadas API.',
    'controller_sha256': hashlib.sha256((REPO / 'scripts/tesis/orquestacion_langgraph.py').read_bytes()).hexdigest(),
    'catalogue_tasks': normal['catalogue_tasks'],
    'maximum_concurrent_tasks': normal['maximum_concurrent_tasks'],
    'existing_ipv6_serialization_preserved': not normal['ipv6_tasks_overlapped'],
    'explicit_segment_lock_events': normal['explicit_segment_lock_events'],
    'same_segment_calls_after_restoration_failure': len(failure['same_segment_calls_after_failure']),
    'affected_assets_after_failure': sorted({c['asset'] for c in failure['same_segment_calls_after_failure']}),
    'rf08_pending': not normal['rf08_explicit_segment_lock_demonstrated'],
    'rf26_pending': not failure['rf26_failure_quarantine_demonstrated'],
}
(HERE / 'diagnostico-11-1/resumen.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
