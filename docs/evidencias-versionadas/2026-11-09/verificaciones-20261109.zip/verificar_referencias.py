"""Verificación editorial nueva y fechada; no reconstruye la selección histórica."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import json
from pathlib import Path
import re
import time
from urllib.parse import quote,urlencode
from urllib.request import Request,urlopen

ROOT=Path(__file__).resolve().parent
IDS={22,23,35,37,38,40,41,42,43,48,2,3,9,17,25,33,34,36,44,45,46,50}
TITLES={2:'PentestGPT: Evaluating and Harnessing Large Language Models for Automated Penetration Testing',
17:'ReAct: Synergizing Reasoning and Acting in Language Models',
33:'PENTEST-AI, an LLM-powered multi-agents framework for penetration testing automation leveraging MITRE ATT&CK',
46:'6SENSE: Internet-wide IPv6 Scanning and its Security Applications',
50:'Shedding Light on CVSS Scoring Inconsistencies: A User-Centric Study on Evaluating Widespread Security Vulnerabilities'}


def fetch(row):
    doi=re.search(r'DOI: ([^ ]+)',row['entrada_original'])
    query=('https://api.crossref.org/works/'+quote(doi[1].rstrip('.'),safe='/') if doi else
           'https://api.crossref.org/works?'+urlencode({'query.title':TITLES[row['numero']],'rows':3}))
    result={'reference':row['numero'],'original_entry':row['entrada_original'],
        'checked_at':datetime.now(timezone.utc).isoformat(),'query':query,'provider':'Crossref publisher-deposited metadata'}
    try:
        with urlopen(Request(query,headers={'User-Agent':'Novaflow-Academic-Reference-Verification/1.0'}),timeout=25) as response:
            payload=json.load(response)['message']
        records=[payload] if doi else payload['items']
        result['candidates']=[{key:item.get(key) for key in ['DOI','title','author','type','container-title','published',
            'published-online','published-print','volume','issue','page','article-number','publisher','URL','abstract','link']} for item in records]
        result['status']='metadata_recovered_requires_content_review'
    except Exception as exc:
        result.update(status='not_recovered',error_type=type(exc).__name__,http_status=getattr(exc,'code',None))
    return result


if __name__=='__main__':
    rows=[r for r in json.loads((ROOT/'seguimiento.json').read_text())['referencias'] if r['numero'] in IDS]
    results=[]
    for row in rows:
        results.append(fetch(row))
        time.sleep(2)
    (ROOT/'verificacion-editorial-11-8-v3.json').write_text(json.dumps({'kind':'current_reference_verification',
        'historical_screening_log':False,'results':results},ensure_ascii=False,indent=2)+'\n')
    for r in results:
        print(r['reference'],r['status'],[(c['DOI'],c['title'],c['type']) for c in r.get('candidates',[])])
