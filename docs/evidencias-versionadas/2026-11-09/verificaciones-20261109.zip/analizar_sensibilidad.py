"""Análisis nuevo de evidencias originales: conserva 50 intentos y 25 parejas.

No ejecuta auditorías, no llama proveedores y no escribe en los insumos.
"""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
from statistics import mean, median

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'revision-respaldo-drive/soportes-recuperados/docs/evaluacion-langgraph'
METRICS=('TRTO_percent','IDE_percent','ETV_ratio')


def summary(pairs):
    return {metric:{'n':len(values),'mean':mean(values) if values else None,
        'median':median(values) if values else None,'min':min(values) if values else None,
        'max':max(values) if values else None} for metric in METRICS
        for values in [[p['metrics'][metric] for p in pairs if p['eligible']]]}


def main():
    inputs={name:(SOURCE/name).read_bytes() for name in ['pairs.json','runs.json','protocol.json']}
    labs=json.loads(inputs['pairs.json']);runs=json.loads(inputs['runs.json'])
    by_sequence={r['sequence']:r for r in runs}
    pairs=[dict(pair,laboratory=lab['id']) for lab in labs for pair in lab['pairs']]
    assert len(runs)==50 and len(by_sequence)==50 and len(pairs)==25
    assert sum(p['eligible'] for p in pairs)==23
    version_groups=defaultdict(list);version_map={}
    for pair in pairs:
        members=[by_sequence[pair[a]['sequence']] for a in ('single','multiagent')]
        identities=[]
        for member in members:
            identity={key:member.get(key) for key in ['source_sha256','adapter_sha256','graph_sha256','graph_version','extensions_sha256']}
            digest=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
            version_map[digest]=identity;identities.append(digest)
        group=identities[0] if identities[0]==identities[1] else 'mixed:'+':'.join(identities)
        version_groups[group].append(pair)
    result={'analysis_date':'2026-11-09','kind':'new_sensitivity_analysis_of_historical_data',
        'input_sha256':{name:hashlib.sha256(raw).hexdigest() for name,raw in inputs.items()},
        'attempts':len(runs),'attempt_statuses':dict(Counter(r['status'] for r in runs)),
        'planned_pairs':25,'eligible_pairs':23,'overall':summary(pairs),
        'by_laboratory':{lab['id']:{'attempts':lab['recorded_runs'],'eligible_pairs':lab['eligible_pairs'],
            'planned_pairs':len(lab['pairs']),'metrics':summary(lab['pairs'])} for lab in labs},
        'leave_one_laboratory_out':{lab['id']:summary([p for p in pairs if p['laboratory']!=lab['id']]) for lab in labs},
        'by_code_identity':{group:{'planned_pairs':len(rows),'eligible_pairs':sum(p['eligible'] for p in rows),
            'laboratories':sorted({p['laboratory'] for p in rows}),'metrics':summary(rows)} for group,rows in version_groups.items()},
        'code_identity_map':version_map,
        'excluded_pairs':[{'laboratory':p['laboratory'],'pair':p['pair'],'single':p['single'],'multiagent':p['multiagent'],
            'reasons':p['reasons'],'metrics':p['metrics']} for p in pairs if not p['eligible']],
        'interpretation':[
            'Las dos parejas no elegibles se conservan en el denominador de 25; los ratios se estiman sobre 23 parejas comparables.',
            'No se imputan tiempos, hallazgos ni ratios a intentos parciales.',
            'La exclusión podría alterar la magnitud del efecto en cualquier dirección; estos datos no demuestran un sesgo conservador.',
            'La comparación combina especialización, coordinación y concurrencia; no identifica un efecto causal aislado de la especialización.',
            'Los estratos de versión y laboratorio pueden estar confundidos y tener pocas observaciones; su comparación es descriptiva.']}
    out=HERE/'sensibilidad-11-9.json'
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ['attempts','attempt_statuses','eligible_pairs','overall','by_laboratory']},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
