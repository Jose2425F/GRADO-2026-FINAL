"""Verificación local de integridad; no ejecuta auditorías ni consulta servicios."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys
import tarfile
import zipfile

HERE = Path(__file__).resolve().parent


def digest_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def safe_path(name):
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and '..' not in relative.parts, 'Ruta inválida')
    path = HERE.joinpath(*relative.parts)
    require(path.resolve().is_relative_to(HERE) and not path.is_symlink(), 'Ruta externa')
    return path


def main():
    manifest = json.loads((HERE/'integridad-paquete.json').read_text())
    for name, expected in manifest['files'].items():
        path = safe_path(name)
        require(path.is_file() and digest_file(path) == expected['sha256'], 'Archivo ausente o diferente: '+name)
        require(path.stat().st_size == expected['bytes'], 'Tamaño diferente: '+name)
    actual = {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()}
    require(actual == set(manifest['files']) | {'integridad-paquete.json'}, 'Inventario de archivos diferente')

    identity = json.loads((HERE/'identidad-codigo-imagenes.json').read_text())
    with zipfile.ZipFile(HERE/'codigo-ejecutado-20261109.zip') as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'Código con entradas duplicadas')
        require(set(names) == set(identity['source_files']), 'Inventario de código diferente')
        for name, expected in identity['source_files'].items():
            require(hashlib.sha256(archive.read(name)).hexdigest() == expected, 'Código diferente: '+name)
    require(digest_file(HERE/'lab-empresa.env') == identity['fixture_sha256'], 'Configuración del laboratorio diferente')

    with tarfile.open(HERE/'imagenes-aceptacion-20261109.tar') as archive:
        image_manifest = json.load(archive.extractfile('manifest.json'))
        image_ids = set()
        for entry in image_manifest:
            configuration = archive.extractfile(entry['Config']).read()
            image_ids.add('sha256:'+hashlib.sha256(configuration).hexdigest())
        require(image_ids == set(identity['images'].values()), 'Imágenes diferentes a la aceptación actual')

    # El archivo publicado conserva la estructura que requiere su propio verificador.
    with zipfile.ZipFile(HERE/'repositorio-publicado-con-evidencias.zip') as archive:
        pub = json.loads(archive.read('docs/evidencias-historicas/2026-10-18/integridad-publicacion.json'))
        for name, expected in pub['files'].items():
            require(hashlib.sha256(archive.read(name)).hexdigest() == expected, 'Evidencia publicada diferente: '+name)
    print(json.dumps({'valid': True, 'files': len(manifest['files']),
                      'source_files': len(identity['source_files']), 'images': len(image_ids),
                      'published_payload_files': len(pub['files']),
                      'historical_execution_reproduced': False,
                      'api_calls': 0, 'network_probes': 0}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, tarfile.TarError, zipfile.BadZipFile) as error:
        print(json.dumps({'valid': False, 'error': str(error)}, ensure_ascii=False))
        sys.exit(1)
