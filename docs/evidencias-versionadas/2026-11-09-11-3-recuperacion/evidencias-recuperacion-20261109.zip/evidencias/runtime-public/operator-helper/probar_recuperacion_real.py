"""Ensayo de operador: leases nuevos, health fallido y recuperación comprobada."""
from pathlib import Path
from datetime import datetime,timezone
import fcntl,hashlib,json,os,signal,stat,subprocess,sys,time
BASE=Path('/var/tmp/c113-9d49e066fefb');ROOT=BASE/'repo';PRIVATE=BASE/'private'
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'piloto_kali/prototipo/src')]
import ejecutar_protegido as operator
BANK='sucursal';STAMP=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
WORK=PRIVATE/('recovery-live-'+STAMP);WORK.mkdir(mode=0o700)
REPORT=WORK/'summary.json';record={'schema':'centinela-live-recovery-test/1','bank':BANK,'status':'running','started_at_utc':STAMP,'openai_api_calls':0,'separate_from_baseline_186':True,'steps':[]}
app_fd=None

def save():operator.write_json(REPORT,record)
def phase(name,**data):
    record['steps'].append({'phase':name,'time':time.time(),**data});save();print(json.dumps({'phase':name,**data}),flush=True)
def stop(signum,frame):raise KeyboardInterrupt('Ensayo detenido por señal.')
for sig in [signal.SIGTERM,signal.SIGHUP,signal.SIGINT]:signal.signal(sig,stop)

def actor_check(locks,segments,namespace,expected):
    code='''import json,sys,types\nfrom pathlib import Path\nsys.path[:0]=[sys.argv[1]+'/scripts',sys.argv[1]+'/piloto_kali/prototipo/src']\nfrom tesis.segmentos import SegmentGuard,SegmentQuarantined\nfrom auditoria.tool_worker import identity,unprivileged\nroot,segments,expected=sys.argv[2],json.loads(sys.argv[3]),sys.argv[4]\nguard=SegmentGuard(Path(root));rows=[]\nfor i,segment in enumerate(segments):\n task=types.SimpleNamespace(task_id='lease_fixture_'+str(i),agent_type='ipv4_services',target=types.SimpleNamespace(interface=segment))\n try:\n  guard.acquire(task);guard.release(task);value={'segment':segment,'acquired_and_released':True}\n except Exception as exc:value={'segment':segment,'error':type(exc).__name__,'errno':getattr(exc,'errno',None)}\n value['passed']=(value.get('acquired_and_released') is True if expected=='clear' else value.get('error')=='SegmentQuarantined')\n rows.append(value)\nidentity=identity();print(json.dumps({'kind':'segment_guard_uid_fixture','identity':identity,'expected':expected,'tests':rows,'passed':unprivileged(identity,65531,65531) and all(x['passed'] for x in rows),'audit_tasks_executed':0}))'''
    args=['/usr/sbin/ip','netns','exec',namespace,'/usr/bin/setpriv','--reuid=65531','--regid=65531','--clear-groups','--inh-caps=-all','--ambient-caps=-all','--bounding-set=-all','--no-new-privs',str(BASE/'venv/bin/python'),'-I','-B','-c',code,str(ROOT),str(locks),json.dumps(segments),expected]
    result=subprocess.run(args,capture_output=True,text=True,timeout=20,env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C.UTF-8'})
    if result.returncode:raise RuntimeError('Falló fixture UID: '+result.stderr[-1000:])
    proof=json.loads(result.stdout);assert proof['passed'];return proof

lock_fd=os.open(PRIVATE/'operator-run.lock',os.O_RDWR|os.O_NOFOLLOW)
try:
    fcntl.flock(lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB);save()
    operator.trusted(operator.__file__)
    lab,_=operator.bank_modules(BANK);network_path,network=operator.select_network(BASE,BANK)
    segments=sorted(bridge for bridge,_,_ in lab.NETWORKS.values());locks=operator.persistent_locks(BASE,BANK)
    assert not list(locks.glob('*.json'))
    archive=WORK/'clean-leases-before-fresh-test';archive.mkdir(mode=0o700);held=[];archived=[]
    try:
        for segment in segments:
            path=locks/(hashlib.sha256(segment.encode()).hexdigest()+'.lock')
            fd=os.open(path,os.O_RDWR|os.O_NOFOLLOW);held.append(fd);info=os.fstat(fd)
            assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==0 and info.st_uid==info.st_gid==65531 and stat.S_IMODE(info.st_mode)==0o600
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            archived.append({'segment':segment,'file':path.name,'inode':info.st_ino,'uid':info.st_uid,'gid':info.st_gid,'mode':'0600','bytes':0})
        assert not list(locks.glob('*.json'))
        for item in archived:(locks/item['file']).rename(archive/item['file'])
    finally:
        for fd in held:os.close(fd)
    phase('clean_existing_leases_archived_without_discarding_quarantine',same_persistent_root=str(locks),quarantine_markers_before=0,archived=archived)
    first=operator.recover_protocols(BASE,BANK);first_data=json.loads(first.read_text())
    assert first_data['status']=='verified' and all(row['created'] for row in first_data['segment_lock_leases'])
    proof=actor_check(locks,segments,network['namespace'],'clear');operator.write_json(WORK/'fresh-actor-acquire.json',proof)
    phase('fresh_lock_root_recovery_then_actor_acquire_passed',receipt=str(first),three_fresh_actor_owned_leases=True,actor_fixture=str(WORK/'fresh-actor-acquire.json'))
    app=next(iter(lab.APPS.values()))['container'];pin=network['expected_endpoints'][app]
    template='{"id":{{json .Id}},"image":{{json .Image}},"pid":{{json .State.Pid}},"running":{{json .State.Running}}}'
    manifest=json.loads((PRIVATE/'bootstrap.json').read_text());current=json.loads(operator.run(['/usr/bin/docker','--host',manifest['docker_host'],'container','inspect','--format',template,app]))
    assert current['id']==pin['container_id'] and current['image']==pin['container_image'] and current['running']
    app_fd=os.pidfd_open(current['pid']);signal.pidfd_send_signal(app_fd,signal.SIGSTOP)
    phase('controlled_application_health_fault_started',container=app,container_id=current['id'],image=current['image'],pid=current['pid'],fault='SIGSTOP process, container identity/network preserved')
    before={p.name for p in PRIVATE.glob('recovery-*.json')}
    try:
        try:operator.recover_protocols(BASE,BANK)
        except operator.OperatorError as exc:failure=type(exc).__name__
        else:raise AssertionError('La recuperación aceptó un preflight sin salud HTTP.')
        created=[p for p in PRIVATE.glob('recovery-*.json') if p.name not in before];assert len(created)==1
        failed=json.loads(created[0].read_text());assert failed['status']=='failed_quarantine_retained'
        markers=list(locks.glob('*.json'));assert len(markers)>=3
        blocked=actor_check(locks,segments,network['namespace'],'quarantined');operator.write_json(WORK/'failed-actor-quarantined.json',blocked)
        phase('failed_preflight_retains_quarantine_and_blocks_actor',receipt=str(created[0]),failure=failure,marker_files=[p.name for p in markers],actor_fixture=str(WORK/'failed-actor-quarantined.json'))
    finally:
        signal.pidfd_send_signal(app_fd,signal.SIGCONT);os.close(app_fd);app_fd=None
    phase('controlled_application_health_fault_removed',container=app)
    final=operator.recover_protocols(BASE,BANK);final_data=json.loads(final.read_text());assert final_data['status']=='verified'
    root_markers=[path for path in locks.glob('*.json') if json.loads(path.read_text()).get('state') in {'recovery_in_progress','restoration_unverified'}];assert not root_markers
    proof=actor_check(locks,segments,network['namespace'],'clear');operator.write_json(WORK/'final-actor-acquire.json',proof)
    phase('verified_preflight_clears_only_after_success_then_actor_acquires',receipt=str(final),quarantine_markers_after=0,actor_fixture=str(WORK/'final-actor-acquire.json'))
    record['status']='passed'
except BaseException as exc:
    record['status']='failed';record['error']=type(exc).__name__+': '+str(exc);raise
finally:
    if app_fd is not None:
        try:signal.pidfd_send_signal(app_fd,signal.SIGCONT)
        finally:os.close(app_fd)
    os.close(lock_fd);record['ended_at_utc']=datetime.now(timezone.utc).isoformat();save();print(json.dumps({'recovery_test_receipt':str(REPORT),'status':record['status']}),flush=True)
