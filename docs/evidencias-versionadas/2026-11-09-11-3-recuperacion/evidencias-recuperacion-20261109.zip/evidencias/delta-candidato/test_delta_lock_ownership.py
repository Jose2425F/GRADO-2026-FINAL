"""QA de leases del delta en fixtures temporales, sin Docker ni receivers."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile

import pytest


pytestmark=pytest.mark.skipif(os.geteuid()!=0,reason='Los contratos UID65531 requieren el operador de fixtures.')


@pytest.fixture
def fixture(monkeypatch):
    source=Path(os.environ['CENTINELA_REVIEW_EXECUTOR'])
    info=source.stat()
    assert info.st_uid==0 and not info.st_mode&0o022
    spec=importlib.util.spec_from_file_location('recovery_candidate_root_frozen',source)
    executor=importlib.util.module_from_spec(spec);spec.loader.exec_module(executor)
    root=Path(tempfile.mkdtemp(prefix='c113-lock-qa-',dir='/var/tmp'));root.chmod(0o755)
    directory=root/'leases';directory.mkdir(mode=0o700);os.chown(directory,65531,65531)
    monkeypatch.setattr(executor,'persistent_locks',lambda *_:directory)
    try:yield executor,root,directory
    finally:shutil.rmtree(root)


def identity(path):
    info=path.lstat()
    return (info.st_uid,info.st_gid,stat.S_IMODE(info.st_mode),info.st_ino,
            info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)


@pytest.mark.parametrize('kind',['symlink','hardlink','wrong_owner','wrong_gid','wrong_mode','fifo'])
def test_unsafe_existing_lease_is_rejected_without_touching_foreign_input(fixture,kind):
    executor,root,directory=fixture
    target=root/'foreign';target.write_text('foreign sentinel');target.chmod(0o640)
    lease=directory/(hashlib.sha256(b'br-fixture').hexdigest()+'.lock')
    if kind=='symlink':lease.symlink_to(target)
    elif kind=='hardlink':os.link(target,lease)
    elif kind=='fifo':
        os.mkfifo(lease,0o600);os.chown(lease,65531,65531)
    else:
        lease.write_text('lease sentinel');lease.chmod(0o600)
        if kind=='wrong_owner':os.chown(lease,0,0)
        else:
            os.chown(lease,65531,0 if kind=='wrong_gid' else 65531)
            if kind=='wrong_mode':lease.chmod(0o640)
    before_foreign=identity(target);before_lease=identity(lease)
    with pytest.raises((executor.OperatorError,OSError)):
        executor.prepare_segment_lock_files(root,'integrado',['br-fixture'])
    assert identity(target)==before_foreign
    assert identity(lease)==before_lease


def test_fresh_recovery_locks_remain_usable_by_uid65531(fixture):
    executor,root,directory=fixture
    rows=executor.prepare_segment_lock_files(root,'integrado',['br-fixture'])
    assert rows[0]['created'] is True
    lease=directory/(hashlib.sha256(b'br-fixture').hexdigest()+'.lock')
    assert lease.stat().st_uid==65531 and lease.stat().st_gid==65531
    assert stat.S_IMODE(lease.stat().st_mode)==0o600
    # La recuperación del fixture como root no debe cambiar esos metadatos.
    stage=Path('/var/tmp/c113-9d49e066fefb/repo/scripts')
    import sys
    sys.path.insert(0,str(stage))
    from tesis.segmentos import SegmentGuard
    SegmentGuard(directory).recover(['br-fixture'],lambda:{'fixture_health_only':True})
    assert lease.stat().st_uid==65531
    code=r'''
import json,os,sys,hashlib
from types import SimpleNamespace
from pathlib import Path
sys.path.insert(0,'/var/tmp/c113-9d49e066fefb/repo/scripts')
from tesis.segmentos import SegmentGuard
class Store:
 def event(self,*args,**kwargs):pass
 def evidence(self,name,kind,body):return name,hashlib.sha256(body).hexdigest()
guard=SegmentGuard(Path(sys.argv[1]),Store())
task=SimpleNamespace(task_id='fixture-only',agent_type='ipv6_ndp',target=SimpleNamespace(interface='br-fixture'))
guard.acquire(task);guard.restored(task,{'fixture_health_only':True});guard.release(task)
fields={k:v.strip() for k,v in (line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines()) if k in {'Uid','Gid','Groups','CapInh','CapPrm','CapEff','CapBnd','CapAmb','NoNewPrivs'}}
print(json.dumps({'uid':os.getuid(),'gid':os.getgid(),'identity':fields,'acquire_restore_release':True}))
'''
    command=['setpriv','--reuid=65531','--regid=65531','--clear-groups','--inh-caps=-all',
        '--ambient-caps=-all','--bounding-set=-all','--no-new-privs','/usr/bin/python3','-I','-B','-c',code,str(directory)]
    result=json.loads(subprocess.check_output(command,text=True,timeout=8))
    assert result['uid']==result['gid']==65531 and result['acquire_restore_release'] is True
    assert result['identity']['Uid'].split()==['65531']*4 and not result['identity']['Groups']
    assert result['identity']['NoNewPrivs']=='1'
    assert all(int(result['identity'][field],16)==0 for field in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb'])
