#!/usr/bin/env python3
"""Publica sólo la continuación de recuperación; nunca escribe el baseline."""
import argparse
from datetime import datetime,timezone
import importlib.util
import json
from pathlib import Path,PurePosixPath
import zipfile

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('baseline_readonly_helpers',BASE/'empaquetar_evidencia_113.py')
helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
DESTINATION='docs/evidencias-versionadas/2026-11-09-11-3-recuperacion'
BASELINE='docs/evidencias-versionadas/2026-11-09-11-3'
BASELINE_SHA='5e6230ce2e059182663be8af8912617c8d003739f74a340111f6b604a00210a5'


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,required=True)
    args=parser.parse_args();config=json.loads(args.config.read_text());repo=Path(config['repository'])
    if config['destination']!=DESTINATION:raise ValueError('El empaquetador sólo escribe la carpeta nueva de recuperación.')
    previous=repo/BASELINE/'evidencias-roles-origen-20261109.zip'
    if helpers.digest(previous.read_bytes())!=BASELINE_SHA:raise ValueError('Cambió el ZIP inmutable del baseline.')
    destination=repo/DESTINATION;destination.mkdir(parents=True,exist_ok=True)
    entries=[];content={};allowed=set(config.get('approved_fictitious_token_sha256',[]))
    for row in config['entries']:
        if set(row)!={'source','entry','classification','note'}:raise ValueError('Aprobación incompleta')
        path,before=helpers.protected_source(row['source']);relative=PurePosixPath(row['entry'])
        if relative.is_absolute() or '..' in relative.parts or str(relative)!=row['entry'] or relative.parts[0]!='evidencias':raise ValueError('Ruta ZIP no válida')
        if str(relative) in content:raise ValueError('Entrada duplicada')
        raw=path.read_bytes();after=path.stat()
        if (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):raise ValueError('Fuente aún cambia: '+str(path))
        helpers.scan(path,raw,allowed);content[str(relative)]=raw
        entries.append(row|{'bytes':len(raw),'sha256':helpers.digest(raw),'source_mtime_ns':before.st_mtime_ns,'byte_identical_copy':True})
    approved={row['source'] for row in entries};checked=[]
    for row in entries:
        path=Path(row['source'])
        if path.name!='manifest-public.json':continue
        manifest=json.loads(path.read_text())
        if manifest.get('exact_fixture_secret_scan_passed') is not True or manifest.get('originals_preserved') is not True:
            raise ValueError('La exportación de recuperación no tiene aprobación de privacidad.')
        for name,pin in manifest['files'].items():
            part=PurePosixPath(name)
            if part.is_absolute() or '..' in part.parts:raise ValueError('Ruta de exportación no válida')
            source=path.parent/part
            if str(source) not in approved:raise ValueError('Falta entrada de la exportación aprobada: '+str(source))
            raw=source.read_bytes()
            if len(raw)!=pin['bytes'] or helpers.digest(raw)!=pin['sha256']:raise ValueError('Exportación alterada: '+str(source))
        checked.append({'source':str(path),'files':len(manifest['files']),'verified':True})
    historical=helpers.conservation(repo,['bc7f7d5','b579f49','489e778'])
    helpers.write(destination/'conservacion-versiones.json',historical)
    archive=destination/'evidencias-recuperacion-20261109.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
        for name,raw in sorted(content.items()):
            info=zipfile.ZipInfo(name,(2026,11,9,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            output.writestr(info,raw)
    helpers.write(destination/'integridad-evidencias.json',{'schema':'centinela-recovery-evidence/1','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'status':config['status'],'scope':'operator_preflight_and_protocol_recovery_only','archive':archive.name,'archive_bytes':archive.stat().st_size,
        'archive_sha256':helpers.digest(archive.read_bytes()),'entry_count':len(entries),'entries':entries,'public_exports_verified':checked,
        'baseline_evidence_commit':'489e778','baseline_archive_sha256':BASELINE_SHA,
        'privacy_review':{'explicit_sources_only':True,'private_sources_excluded':True,'configured_keys_not_read':True,'known_pattern_scan_passed':True,
            'note':'Revisión por patrones y campos conocidos; no garantiza detectar cualquier secreto desconocido.'}})
    helpers.write(destination/'fuentes-aprobadas.json',config)
    publication=[]
    for path in sorted(destination.iterdir()):
        if not path.is_file() or path.name=='integridad-publicacion.json':continue
        raw=path.read_bytes();publication.append({'path':path.name,'bytes':len(raw),'sha256':helpers.digest(raw)})
    for path in sorted((repo/'docs/ajustes-profesor/2026-11-09-recuperacion').iterdir()):
        if path.is_file():
            raw=path.read_bytes();publication.append({'path':'../../ajustes-profesor/2026-11-09-recuperacion/'+path.name,'bytes':len(raw),'sha256':helpers.digest(raw)})
    helpers.write(destination/'integridad-publicacion.json',{'schema':'centinela-recovery-publication-integrity/1','files':publication})
    print(json.dumps({'status':config['status'],'entries':len(entries),'archive_bytes':archive.stat().st_size,'archive_sha256':helpers.digest(archive.read_bytes()),
        'historical_reference_counts':[row['count'] for row in historical['revisions']],'baseline_unchanged':True}))

if __name__=='__main__':main()
