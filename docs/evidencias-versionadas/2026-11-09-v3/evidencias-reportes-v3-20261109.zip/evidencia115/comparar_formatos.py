"""Regenera proyecciones de registros guardados; no ejecuta auditorías."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import argparse, copy, hashlib, json, sys

parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,required=True);parser.add_argument('--label',choices=['antes','despues'],required=True);args=parser.parse_args()
base=Path(__file__).resolve().parent;out=base/args.label;out.mkdir(exist_ok=True)
sys.path[:0]=[str(args.repo/'piloto_kali/prototipo/src'),str(args.repo/'scripts')]
from auditoria.modulo_reportes import save_report
if args.label=='despues':from auditoria.modulo_reportes import prepare_report
package=args.repo/'docs/evidencias-versionadas/2026-11-09-11-3'
summary=json.loads((package/'resumen-validacion.json').read_text());manifest=json.loads((package/'integridad-evidencias.json').read_text());archive=package/manifest['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
jobs=[(bank,info) for bank,info in summary['catalogue_final_accepted'].items() if isinstance(info,dict) and info.get('accepted') is True]
jobs.append(('integrado-multi',summary['supplementary_multiagent']))
rows=[]
with ZipFile(archive) as z:
    names=set(z.namelist())
    for bank,info in jobs:
        candidates=[n for n in names if n.startswith(info['source']+'/') and n.endswith('/report.json')];assert len(candidates)==1
        reference=candidates[0];prefix=reference.removesuffix('report.json');raw=z.read(reference);original=json.loads(raw);request=json.loads(z.read(prefix+'request.json'));plan=json.loads(z.read(prefix+'plan.json'));report=copy.deepcopy(original)
        assert request['audit_id']==report['audit_id']
        planned={x['task_id']:x for x in plan};results={x['task_id']:x for x in report['tasks']};assert set(planned)==set(results)
        attempt_ids=[r.get('attempt_id') for r in report['tasks']];assert all(isinstance(x,str) and len(x)==32 for x in attempt_ids) and len(set(attempt_ids))==len(attempt_ids)
        checks=0;creds=0
        for task in plan:
            result=results[task['task_id']]
            for field,pin in [('evidence_ref','evidence_sha256'),('diagnostic_ref','diagnostic_sha256')]:
                if not result.get(field):continue
                part=PurePosixPath(result[field]);assert not part.is_absolute() and '..'not in part.parts
                entry=prefix+str(part);assert entry in names
                assert hashlib.sha256(z.read(entry)).hexdigest()==result[pin];checks+=1
            if task['agent_type']=='ipv4_credentials':
                assert len(task['dependencies'])==1
                dependency=planned[task['dependencies'][0]];discovery=results[dependency['task_id']]
                assert dependency['target']==task['target'] and dependency['action_profile']=='nmap_tcp_services_v1'
                assert discovery['status'] in {'completed','completed_no_findings'}
                auth=result['authentication'];assert auth and any(s['protocol']=='tcp' and s['state']=='open' and s['port']==auth['port'] for s in discovery['services']);creds+=1
        if args.label=='despues':report=prepare_report(report,request)
        target=out/bank;target.mkdir(exist_ok=True)
        (target/'request.source.json').write_bytes(z.read(prefix+'request.json'))
        (target/'plan.source.json').write_bytes(z.read(prefix+'plan.json'))
        (target/'report.source.json').write_bytes(raw)
        save_report(target,report)
        persisted=json.loads((target/'report.json').read_text());html=(target/'report.html').read_text()
        findings=persisted['findings'];ids=[x.get('finding_id') for x in findings]
        inv_refs=[d for i in persisted.get('inventory',[]) for d in i.get('discovery_tasks',[])]
        row={'bank':bank,'run_id':info['run_id'],'source_report_entry':reference,'source_report_sha256':hashlib.sha256(raw).hexdigest(),'audit_id':persisted['audit_id'],'tasks':len(results),'unique_attempts':len(set(attempt_ids)),'evidence_digest_checks':checks,'credential_dependencies_checked':creds,'inventory_records':len(persisted['inventory']),'inventory_discovery_links':len(inv_refs),'finding_count':len(findings),'finding_ids':ids,'scope_present':bool(persisted.get('scope')),'html_has_all_finding_ids':all(x in html for x in ids if x),'html_has_all_discovery_attempts':all(d.get('attempt_id') and d['attempt_id'] in html for d in inv_refs),'generated_formats':['JSON','HTML','PDF'],'new_audit_executed':False,'artifacts':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in target.iterdir() if f.is_file()}}
        if args.label=='despues':assert row['scope_present'] and all(ids) and len(set(ids))==len(ids) and row['html_has_all_finding_ids'] and row['html_has_all_discovery_attempts']
        rows.append(row)
receipt={'label':args.label,'application_source':str(args.repo),'historical_package_sha256':manifest['archive_sha256'],'cases':rows,'task_results_read':sum(x['tasks'] for x in rows),'new_audits_executed':False,'source_package_modified':False}
(out/'resumen.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'label':args.label,'cases':len(rows),'tasks_read':receipt['task_results_read'],'findings':sum(x['finding_count'] for x in rows),'scopes_present':sum(x['scope_present'] for x in rows),'all_six_request_plan_report_chains_and_evidence_digests_valid':True},ensure_ascii=False))
