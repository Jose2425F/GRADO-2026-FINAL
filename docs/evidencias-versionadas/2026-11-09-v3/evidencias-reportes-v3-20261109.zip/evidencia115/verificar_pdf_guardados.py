"""Coteja PDF exportados contra sus JSON; no ejecuta el aplicativo ni auditorías.

Usar el Python bundled con pypdf y pdfplumber. Los PDF se generan previamente con
comparar_formatos.py. El resultado nuevo no sustituye el primer recibo guardado.
"""
from pathlib import Path
from pypdf import PdfReader
import pdfplumber
import json,re
base=Path(__file__).resolve().parent
normalize=lambda text:re.sub(r'\s+','',text)
rows=[]
for label in ['antes','despues']:
    summary=json.loads((base/label/'resumen.json').read_text())
    for case in summary['cases']:
        root=base/label/case['bank'];report=json.loads((root/'report.json').read_text());reader=PdfReader(root/'report.pdf');flat=normalize('\n'.join(page.extract_text() for page in reader.pages))
        values={'finding_ids':[f['finding_id'] for f in report['findings'] if f.get('finding_id')],
                'attempt_ids':[t['attempt_id'] for t in report['tasks'] if t.get('attempt_id')],
                'task_ids':[t['task_id'] for t in report['tasks']],
                'inventory_addresses':[item['address'] for item in report['inventory'] if item.get('address')],
                'declared_ranges':report.get('scope',{}).get('ipv4',[])+report.get('scope',{}).get('ipv6',[])}
        checks={key:{'expected':len(items),'present':sum(normalize(value) in flat for value in items),'missing':[value for value in items if normalize(value) not in flat]} for key,items in values.items()}
        outside=[]
        with pdfplumber.open(root/'report.pdf') as pdf:
            for i,page in enumerate(pdf.pages):
                for char in page.chars:
                    if char['x0']<0 or char['top']<0 or char['x1']>page.width+0.5 or char['bottom']>page.height+0.5:
                        outside.append({'page':i+1,'bounds':[char['x0'],char['top'],char['x1'],char['bottom']]})
        passed=not outside and all(not check['missing'] for check in checks.values())
        if label=='despues' and not passed:raise ValueError('Proyección incompleta o fuera de página: '+case['bank'])
        rows.append({'label':label,'bank':case['bank'],'pages':len(reader.pages),'checks':checks,'text_outside_page':outside,'content_checks_passed':passed})
result={'results':rows,'all_after_passed':all(x['content_checks_passed'] for x in rows if x['label']=='despues'),'no_new_audits':True}
(base/'cotejo-pdf-real-recalculado.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all_after_passed':result['all_after_passed'],'cases':6,'source':'Stored JSON/HTML/PDF projections only; no auditor tools.'}))
