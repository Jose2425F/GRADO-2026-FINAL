import ipaddress
import os
import socket
import subprocess

def local(host):
    if host in (None, '', 'localhost'):
        return True
    try:
        return ipaddress.ip_address(str(host).split('%', 1)[0]).is_loopback
    except ValueError:
        return False

def denied():
    raise OSError('CI: conexión o herramienta de auditoría no autorizada')

original_connect = socket.socket.connect
original_connect_ex = socket.socket.connect_ex
original_bind = socket.socket.bind
original_sendto = socket.socket.sendto
original_getaddrinfo = socket.getaddrinfo
original_popen = subprocess.Popen

def check(sock, address):
    if sock.family in (socket.AF_INET, socket.AF_INET6) and not local(address[0]):
        denied()
    if sock.family == getattr(socket, 'AF_PACKET', -1):
        denied()
    if sock.family == socket.AF_UNIX and 'docker' in str(address).lower():
        denied()

def connect(sock, address):
    check(sock, address)
    return original_connect(sock, address)

def connect_ex(sock, address):
    check(sock, address)
    return original_connect_ex(sock, address)

def bind(sock, address):
    check(sock, address)
    return original_bind(sock, address)

def sendto(sock, data, *args):
    check(sock, args[-1])
    return original_sendto(sock, data, *args)

def getaddrinfo(host, *args, **kwargs):
    # Scapy consulta direcciones numéricas al importar sus parsers.
    # Resolver un literal no es una consulta DNS ni una sonda.
    if not local(host):
        try:
            ipaddress.ip_address(str(host).split('%', 1)[0])
        except ValueError:
            denied()
    return original_getaddrinfo(host, *args, **kwargs)

def local_nmap(args):
    # La integración HTTP existente usa un único puerto efímero de
    # sus servidores 127.0.0.1/::1; no se admiten otros perfiles.
    values = list(args[1:])
    ipv6 = bool(values and values[0] == '-6')
    if ipv6:
        values.pop(0)
    prefix = ['--unprivileged', '-n', '-Pn', '-sT', '-sV', '--version-light',
              '--max-retries', '1', '--host-timeout', '60s', '-e', 'lo', '-p']
    if len(values) != len(prefix) + 4 or values[:len(prefix)] != prefix:
        return False
    port, xml, stdout, target = values[len(prefix):]
    return (isinstance(port, str) and port.isascii() and port.isdecimal()
            and 1024 <= int(port) <= 65535 and [xml, stdout] == ['-oX', '-']
            and target == ('::1' if ipv6 else '127.0.0.1'))

def popen(args, *positional, **kwargs):
    if kwargs.get('shell') or not isinstance(args, (list, tuple)) or not args:
        denied()
    command = os.path.basename(os.fsdecode(args[0]))
    blocked = {'docker', 'docker-compose', 'dockerd', 'containerd', 'nmap',
               'hydra', 'sudo', 'su', 'pkexec', 'setpriv', 'unshare', 'nsenter',
               'mount', 'umount', 'nft', 'iptables', 'ip6tables', 'tcpdump',
               'ping', 'ping6', 'curl', 'wget', 'nc', 'ncat', 'ssh', 'ftp', 'psql'}
    if command in blocked:
        denied()
    if command == 'ip' and set(map(str, args[1:])) & {
        'add', 'del', 'delete', 'replace', 'set', 'exec', 'flush', 'netns', 'tunnel'
    }:
        denied()
    return original_popen(args, *positional, **kwargs)

socket.socket.connect = connect
socket.socket.connect_ex = connect_ex
socket.socket.bind = bind
socket.socket.sendto = sendto
socket.getaddrinfo = getaddrinfo
subprocess.Popen = popen
