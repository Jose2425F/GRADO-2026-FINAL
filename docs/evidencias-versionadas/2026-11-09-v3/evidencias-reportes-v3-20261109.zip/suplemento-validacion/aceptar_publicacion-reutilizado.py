#!/usr/bin/env python3
"""Aceptación en un clon nuevo; sólo escribe en la salida y cachés declaradas.

No instala paquetes globales, no inicia laboratorios y no usa el daemon Docker.
Las credenciales de la cuenta de humo sólo existen en memoria y datos temporales.
"""
from pathlib import Path
import argparse
import hashlib
import http.client
import json
import os
import re
import secrets
import shutil
import signal
import socket
import subprocess
import tempfile
import time

BASE = Path(__file__).resolve().parent
OLD = BASE / 'aceptacion-final'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def tracked(repo):
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).split(b'\0')
    result = {}
    for raw in paths:
        if raw:
            name = os.fsdecode(raw)
            path = repo / name
            result[name] = {'symlink': os.readlink(path)} if path.is_symlink() else sha(path)
    return result


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()


def command(args, label, cwd, env, out, records, timeout=900):
    log = out / (label + '.log')
    start = time.time()
    print(json.dumps({'step': label, 'argv': list(map(str, args))}), flush=True)
    with log.open('wb') as stream:
        result = subprocess.run(list(map(str, args)), cwd=cwd, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
    records.append({'label': label, 'argv': list(map(str, args)), 'exit_code': result.returncode,
                    'elapsed_seconds': round(time.time()-start, 3), 'log': str(log), 'sha256': sha(log)})
    (out/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    if result.returncode:
        raise RuntimeError(label+' returned '+str(result.returncode)+'; see '+str(log))


def extract_guard(repo, out):
    guard = out/'browser-guard'
    guard.mkdir()
    text = (repo/'.github/workflows/pruebas.yml').read_text()
    marker = "          cat > \"$RUNNER_TEMP/centinela-guards/sitecustomize.py\" <<'PY'\n"
    embedded = text.split(marker, 1)[1].split('\n          PY\n', 1)[0]
    code = '\n'.join(line[10:] if line.startswith(' '*10) else line for line in embedded.splitlines())+'\n'
    compile(code, str(guard/'sitecustomize.py'), 'exec')
    (guard/'sitecustomize.py').write_text(code)
    return guard


def wrapper(repo, out, guard):
    temporary = Path(tempfile.mkdtemp(prefix='centinela-publicacion-wrapper-'))
    os.chmod(temporary, 0o700)
    (temporary/'home').mkdir(mode=0o700)
    password = secrets.token_urlsafe(32)
    username = 'wrapper-'+secrets.token_hex(6)
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(temporary/'home'),
           'CENTINELA_DATA_DIR': str(temporary/'data'),
           'DOCKER_HOST': 'unix://'+str(temporary/'no-docker.sock'),
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'PYTHONPATH': str(guard),
           'LANGSMITH_TRACING': 'false', 'LANGCHAIN_TRACING_V2': 'false'}
    record = {'status': 'running', 'data_and_account_are_temporary': True,
              'docker_endpoint_is_nonexistent_temporary_socket': True,
              'existing_panel_contacted': False, 'audit_requests_sent': 0, 'provider_requests_sent': 0}
    backend = None
    try:
        result = subprocess.run([str(repo/'piloto_kali/prototipo/.venv/bin/python'),
                                 str(repo/'scripts/administrar_centinela.py'), '--data-dir',
                                 str(temporary/'data'), 'crear-admin', username,
                                 '--nombre', 'Aceptación temporal publicación'],
                                cwd=repo, env=env, input=password+'\n'+password+'\n',
                                capture_output=True, text=True, start_new_session=True, timeout=20)
        (out/'wrapper-admin.log').write_text((result.stdout+result.stderr).replace(password, '[redacted]'))
        assert result.returncode == 0, 'Temporary admin CLI failed'
        with socket.socket() as port_socket:
            port_socket.bind(('127.0.0.1', 0))
            port = port_socket.getsockname()[1]
        assert port > 1024 and port != 8765
        argv = ['./scripts/iniciar_panel.sh', '--runs', str(temporary/'runs'), '--port', str(port)]
        record.update(admin_cli_exit_code=0, port=port, argv=argv)
        with (out/'wrapper-backend.log').open('wb') as stream:
            backend = subprocess.Popen(argv, cwd=repo, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
        record['owned_backend_pid'] = backend.pid
        for _ in range(100):
            assert backend.poll() is None, 'Owned wrapper backend exited prematurely'
            connection = http.client.HTTPConnection('127.0.0.1', port, timeout=0.5)
            try:
                connection.request('GET', '/login')
                response = connection.getresponse()
                body = response.read()
                if response.status == 200:
                    assert b'login-form' in body
                    record['get_login_status'] = 200
                    break
            except (ConnectionError, TimeoutError, OSError):
                pass
            finally:
                connection.close()
            time.sleep(0.1)
        else:
            raise AssertionError('Owned wrapper backend did not become ready')
        cmdline = Path('/proc', str(backend.pid), 'cmdline').read_bytes().split(b'\0')
        assert str(repo/'scripts/dualstack_panel.py').encode() in cmdline
        record.update(wrapper_executes_clone_backend=True, status='passed')
    except BaseException as error:
        record.update(status='failed', error=str(error).replace(password, '[redacted]'))
        raise
    finally:
        if backend is not None and backend.poll() is None:
            backend.send_signal(signal.SIGINT)
            try:
                backend.wait(timeout=5)
            except subprocess.TimeoutExpired:
                backend.kill()
                backend.wait(timeout=5)
        record['owned_backend_stopped'] = backend is None or backend.poll() is not None
        shutil.rmtree(temporary)
        record['temporary_data_removed'] = not temporary.exists()
        (out/'wrapper-summary.json').write_text(json.dumps(record, indent=2)+'\n')
    return record


def inventory(repo, out):
    code = """import importlib.metadata as m,json,platform,pathlib,tomllib,sys
lock=tomllib.loads(pathlib.Path(sys.argv[1]).read_text())
installed={d.metadata['Name'].lower().replace('_','-'):d.version for d in m.distributions()}
bad=[{'name':p['name'],'locked':p['version'],'installed':installed[p['name']]} for p in lock['package'] if p['name'] in installed and p['version']!=installed[p['name']]]
print(json.dumps({'python':platform.python_version(),'lock_package_entries':len(lock['package']),'installed_distributions':installed,'installed_count':len(installed),'installed_version_mismatches':bad}))
"""
    result = {}
    for name, python, lock in [('prototype', 'piloto_kali/prototipo/.venv/bin/python', 'piloto_kali/prototipo/uv.lock'),
                               ('legacy', '.venv/bin/python', 'uv.lock')]:
        row = json.loads(subprocess.check_output([str(repo/python), '-c', code, lock], cwd=repo, text=True))
        assert row['python'] == '3.13.15'
        assert not row['installed_version_mismatches']
        row['lock_sha256'] = sha(repo/lock)
        result[name] = row
    (out/'environment-inventory.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', required=True, type=Path)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    source, out = args.candidate.resolve(), args.out.resolve()
    assert out != source and source not in out.parents, 'Output must be outside candidate'
    assert len(args.commit) == 40 and re.fullmatch('[0-9a-f]{40}', args.commit), 'Use the exact commit SHA'
    assert git(source, 'rev-parse', args.commit) == args.commit
    out.mkdir(parents=True, exist_ok=False)
    repo = out/'repo'
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(out/'home'), 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
           'PIP_CONFIG_FILE': '/dev/null', 'PIP_CACHE_DIR': str(OLD/'pip-cache'),
           'UV_CACHE_DIR': str(OLD/'uv-cache'), 'UV_PYTHON_INSTALL_DIR': str(OLD/'managed-python'),
           'UV_PYTHON_BIN_DIR': str(out/'bin'), 'UV_NO_CONFIG': '1',
           'XDG_DATA_HOME': str(out/'xdg-data'), 'PYTHONNOUSERSITE': '1',
           'DOCKER_HOST': 'unix://'+str(out/'nonexistent-docker.sock'),
           'npm_config_cache': str(OLD/'npm-cache'), 'npm_config_userconfig': str(out/'npm-userconfig'),
           'npm_config_globalconfig': str(out/'npm-globalconfig'), 'npm_config_audit': 'false',
           'npm_config_fund': 'false', 'PLAYWRIGHT_BROWSERS_PATH': str(OLD/'playwright-browsers')}
    (out/'home').mkdir(mode=0o700)
    for name in ('npm-userconfig', 'npm-globalconfig'):
        (out/name).write_text('')
    records = []
    summary = {'status': 'running', 'candidate': str(source), 'commit': args.commit, 'clone': str(repo),
               'downloads_cache_reused': True, 'application_virtualenvs_reused': False,
               'global_aws_configuration_changed': False, 'remote_push_performed': False,
               'limits': ['No apt/systemctl/usermod or global OS prerequisite installation.',
                          'No Docker daemon, image builds/pulls, laboratory startup or firewall/route/cgroup changes.',
                          'Reuses downloaded Python3.13.15 and managed Chromium; creates new venvs and npm install.',
                          'Uses pinned external npm11.17.0 because host npm is absent.',
                          'Validates a fresh checkout on the existing host, not a new OS/VM.']}
    tests = None
    test_log = None
    try:
        command(['git', 'clone', '--no-hardlinks', '--no-checkout', source, repo], 'clone', out, env, out, records)
        command(['git', 'checkout', '--detach', args.commit], 'checkout', repo, env, out, records)
        assert git(repo, 'status', '--porcelain') == ''
        assert not (repo/'.git/objects/info/alternates').exists()
        before = tracked(repo)
        (out/'source-before.json').write_text(json.dumps(before, indent=2)+'\n')
        python = OLD/'managed-python/cpython-3.13.15-linux-x86_64-gnu/bin/python3.13'
        command([python, '-m', 'venv', '.venv-uv'], 'bootstrap-venv', repo, env, out, records)
        command(['.venv-uv/bin/python', '-m', 'pip', 'install', 'uv==0.13.7'], 'install-pinned-uv', repo, env, out, records)
        command(['.venv-uv/bin/uv', '--version'], 'uv-version', repo, env, out, records)
        command(['.venv-uv/bin/uv', 'python', 'install', '3.13.15'], 'managed-python', repo, env, out, records)
        for project, extras, label in [('piloto_kali/prototipo', ['ipv6', 'test'], 'prototype'), ('.', ['dev'], 'legacy')]:
            argv = ['.venv-uv/bin/uv', 'sync', '--project', project, '--python', '3.13.15', '--frozen']
            for extra in extras:
                argv.extend(['--extra', extra])
            command(argv, label+'-frozen', repo, env, out, records)
            command(['.venv-uv/bin/uv', 'lock', '--project', project, '--check'], label+'-lock-check', repo, env, out, records)
        summary['environment_inventory'] = inventory(repo, out)
        guard = extract_guard(repo, out)
        env['CENTINELA_CI_GUARD_PATH'] = str(guard)
        test_log = (out/'python-acceptance.log').open('wb')
        tests = subprocess.Popen(['/usr/bin/python3', str(BASE/'verificar_python_clon.py'), '--repo', str(repo),
                                  '--out', str(out/'python-tests')], cwd=out, env=env,
                                 stdout=test_log, stderr=subprocess.STDOUT)
        npm = BASE/'herramientas-node/npm11/package/bin/npm-cli.js'
        command(['node', '--version'], 'node-version', repo, env, out, records)
        command(['node', npm, '--version'], 'npm-version', repo, env, out, records)
        command(['node', npm, 'ci', '--prefix', 'scripts/tests'], 'npm-ci', repo, env, out, records)
        command(['./scripts/tests/node_modules/.bin/playwright', '--version'], 'playwright-version', repo, env, out, records)
        command(['./scripts/tests/node_modules/.bin/playwright', 'install', 'chromium'], 'managed-chromium', repo, env, out, records)
        command(['node', npm, 'test', '--prefix', 'scripts/tests'], 'dom-tests', repo, env, out, records)
        env['CENTINELA_SMOKE_ARTIFACTS'] = str(out/'browser-smoke')
        command(['node', npm, 'run', 'test:browser', '--prefix', 'scripts/tests'], 'browser-smoke', repo, env, out, records)
        summary['browser'] = json.loads((out/'browser-smoke/summary.json').read_text())
        summary['wrapper'] = wrapper(repo, out, guard)
        print(json.dumps({'step': 'waiting-python-suite', 'pid': tests.pid}), flush=True)
        assert tests.wait(timeout=900) == 0, 'Python acceptance failed'
        test_log.close()
        summary['python'] = json.loads((out/'python-tests/summary.json').read_text())
        assert summary['python']['passed']
        after = tracked(repo)
        (out/'source-after.json').write_text(json.dumps(after, indent=2)+'\n')
        summary['source_unchanged'] = before == after
        summary['git_status'] = git(repo, 'status', '--porcelain')
        assert summary['source_unchanged'] and summary['git_status'] == ''
        summary['status'] = 'passed_with_explicit_environment_limits'
    except BaseException as error:
        summary.update(status='failed', error=str(error))
        raise
    finally:
        # Do not interrupt a suite that may be finishing its own owned-process cleanup.
        if tests is not None and tests.poll() is None:
            summary['python_exit_code_after_wait'] = tests.wait(timeout=900)
        if test_log is not None and not test_log.closed:
            test_log.close()
        summary['commands'] = records
        (out/'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False)+'\n')
        print(json.dumps({'status': summary['status'], 'summary': str(out/'summary.json')}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
