#!/usr/bin/env python3
"""Validación suplementaria sin editar fuentes ni contactar servicios vivos."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
REPO = WORK / 'documento-v3-20261109/codigo-cotejo'
OLD = WORK / 'orden-repo-publico-20261109'
RUNTIME = Path('RUNTIME_BUNDLED/codex-primary-runtime/dependencies')
NODE = RUNTIME / 'node/bin/node'
UV = OLD / 'herramientas/bin/uv'
NPM = OLD / 'herramientas-node/npm11/package/bin/npm-cli.js'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    output = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=REPO)
    rows = {}
    for raw in output.split(b'\0'):
        if raw:
            name = os.fsdecode(raw)
            path = REPO / name
            rows[name] = {'symlink': os.readlink(path)} if path.is_symlink() else sha(path)
    return rows


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    started = datetime.now(timezone.utc).isoformat()
    summary = {'started_at': started, 'repo': str(REPO), 'status': 'running',
               'scope': 'Software validation supplement; not a live bank acceptance or deployed-service update.',
               'source_edits': False, 'aws_configuration_changed': False,
               'existing_panel_contacted': False, 'provider_requests': 0,
               'docker_daemon_contacted': False, 'historical_evidence_overwritten': False}
    records = []
    before = inventory()
    write('source-before.json', before)
    summary['git_head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    summary['git_status_before'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True)
    panel_before = Path('/proc/34290/stat').read_text()
    summary['existing_panel_pid'] = 34290
    summary['kernel_taint_before'] = int(Path('/proc/sys/kernel/tainted').read_text())
    assert not summary['kernel_taint_before'] & ((1 << 7) | (1 << 14)), 'Kernel guard rejected environment'
    spec = importlib.util.spec_from_file_location('previous_acceptance_helper', OLD / 'aceptar_publicacion.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    guard = helper.extract_guard(REPO, ROOT)
    base_guard = (guard / 'sitecustomize.py').read_text()
    # Browser/legacy never need real audit tools. Keep this stronger than CI.
    (guard / 'sitecustomize.py').write_text(base_guard + '\nlocal_nmap = lambda args: False\n')
    supplement = ROOT / 'nmap-loopback-guard'
    supplement.mkdir()
    binaries = ROOT / 'nmap-copy'
    binaries.mkdir()
    shutil.copyfile('/usr/lib/nmap/nmap', binaries / 'nmap')
    (binaries / 'nmap').chmod(0o555)
    source_caps = subprocess.check_output(['getcap', '/usr/lib/nmap/nmap'], text=True).strip()
    copy_caps = subprocess.check_output(['getcap', str(binaries / 'nmap')], text=True).strip()
    assert copy_caps == ''
    write('nmap-executable.json', {'source': '/usr/lib/nmap/nmap', 'copy': str(binaries / 'nmap'),
                                 'source_sha256': sha(Path('/usr/lib/nmap/nmap')),
                                 'copy_sha256': sha(binaries / 'nmap'),
                                 'source_file_capabilities': source_caps, 'copy_file_capabilities': [],
                                 'system_executable_modified': False})
    extra = r'''
# Supplemental guard: the exact Nmap fixture must own both listening sockets.
import ctypes
import weakref
import json
import time
_libc = ctypes.CDLL(None, use_errno=True)
if _libc.prctl(38, 1, 0, 0, 0) != 0:
    raise OSError('NoNewPrivs could not be installed for supplemental test')
_listeners = []
_ci_bind = socket.socket.bind
_ci_popen = subprocess.Popen
def fixture_bind(sock, address):
    result = _ci_bind(sock, address)
    if sock.family in (socket.AF_INET, socket.AF_INET6) and address[0] in ('127.0.0.1', '::1'):
        _listeners.append(weakref.ref(sock))
    return result
def fixture_nmap(args, *positional, **kwargs):
    if isinstance(args, (list, tuple)) and args and os.path.basename(os.fsdecode(args[0])) == 'nmap':
        if not local_nmap(args): denied()
        port = int(args[list(args).index('-p') + 1])
        families = set()
        for reference in _listeners:
            sock = reference()
            if sock is None or sock.fileno() < 0: continue
            if (sock.getsockname()[1] == port and sock.getsockopt(socket.SOL_SOCKET, socket.SO_ACCEPTCONN)):
                families.add(sock.family)
        if families != {socket.AF_INET, socket.AF_INET6}: denied()
        if kwargs.get('preexec_fn') is not None: denied()
        args = [os.environ['CENTINELA_TEST_NMAP_COPY'], *args[1:]]
        with open(os.environ['CENTINELA_TEST_NMAP_LOG'], 'a') as log:
            log.write(json.dumps({'at': time.time(), 'pid': os.getpid(), 'argv': args,
                                  'port_owned_by_current_process': True,
                                  'listening_families': sorted(families), 'no_new_privs': 1}) + '\n')
    return _ci_popen(args, *positional, **kwargs)
socket.socket.bind = fixture_bind
subprocess.Popen = fixture_nmap
'''
    (supplement / 'sitecustomize.py').write_text(base_guard + extra)
    compile((supplement / 'sitecustomize.py').read_text(), str(supplement / 'sitecustomize.py'), 'exec')
    env = {'PATH': str(RUNTIME / 'node/bin') + ':/usr/bin:/bin', 'HOME': str(ROOT / 'home'),
           'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'PIP_CONFIG_FILE': '/dev/null',
           'UV_CACHE_DIR': str(OLD / 'aceptacion-final/uv-cache'),
           'UV_PYTHON_INSTALL_DIR': str(OLD / 'aceptacion-final/managed-python'), 'UV_NO_CONFIG': '1',
           'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'DOCKER_HOST': 'unix://' + str(ROOT / 'nonexistent-docker.sock'),
           'OPENAI_API_KEY': '', 'ANTHROPIC_API_KEY': '',
           'LANGSMITH_TRACING': 'false', 'LANGCHAIN_TRACING_V2': 'false',
           'npm_config_cache': str(OLD / 'aceptacion-final/npm-cache'),
           'npm_config_userconfig': str(ROOT / 'npm-userconfig'),
           'npm_config_globalconfig': str(ROOT / 'npm-globalconfig'),
           'npm_config_audit': 'false', 'npm_config_fund': 'false',
           'PLAYWRIGHT_BROWSERS_PATH': str(OLD / 'aceptacion-final/playwright-browsers')}
    (ROOT / 'home').mkdir(mode=0o700)
    for name in ('npm-userconfig', 'npm-globalconfig'):
        (ROOT / name).write_text('')

    def command(args, label, current_env=env, timeout=600):
        helper.command(args, label, REPO, current_env, ROOT, records, timeout=timeout)

    try:
        command([UV, 'sync', '--project', '.', '--python', '3.13.15', '--frozen', '--extra', 'dev', '--offline'], 'legacy-frozen')
        command([NODE, '--version'], 'node-version')
        command([NODE, NPM, '--version'], 'npm-version')
        command([NODE, NPM, 'ci', '--prefix', 'scripts/tests', '--offline'], 'npm-ci')
        protected_env = dict(env, CENTINELA_CI_GUARD_PATH=str(guard), PYTHONPATH=str(guard))
        command([REPO / '.venv/bin/python', '-m', 'pytest', '-q', 'tests', '-o',
                 'cache_dir=' + str(ROOT / 'cache-legacy'), '--junitxml=' + str(ROOT / 'legacy-junit.xml')],
                'legacy-tests', protected_env)
        command([NODE, NPM, 'test', '--prefix', 'scripts/tests'], 'dom-tests', protected_env)
        protected_env['CENTINELA_SMOKE_ARTIFACTS'] = str(ROOT / 'browser-smoke')
        command([NODE, NPM, 'run', 'test:browser', '--prefix', 'scripts/tests'], 'browser-smoke', protected_env)
        summary['browser'] = json.loads((ROOT / 'browser-smoke/summary.json').read_text())
        summary['wrapper'] = helper.wrapper(REPO, ROOT, guard)
        nmap_env = dict(env, PYTHONPATH=str(supplement) + os.pathsep + str(REPO / 'scripts'),
                        CENTINELA_CI_GUARD_PATH=str(supplement), NMAPDIR='/usr/share/nmap',
                        CENTINELA_TEST_NMAP_COPY=str(binaries / 'nmap'),
                        CENTINELA_TEST_NMAP_LOG=str(ROOT / 'nmap-authorizations.jsonl'))
        command([REPO / 'piloto_kali/prototipo/.venv/bin/python', '-m', 'pytest',
                 '-c', 'piloto_kali/prototipo/pyproject.toml', '-q',
                 'scripts/tests/test_aplicaciones_personales.py::ApplicationTests::test_whole_runner_real_nmap_and_web_without_api_in_both_architectures',
                 '-o', 'cache_dir=' + str(ROOT / 'cache-nmap'),
                 '--junitxml=' + str(ROOT / 'nmap-loopback-junit.xml')], 'nmap-loopback-test', nmap_env)
        authorizations = [json.loads(line) for line in (ROOT / 'nmap-authorizations.jsonl').read_text().splitlines()]
        assert len(authorizations) == 4
        assert {row['argv'][-1] for row in authorizations} == {'127.0.0.1', '::1'}
        assert all(row['port_owned_by_current_process'] and row['no_new_privs'] == 1 for row in authorizations)
        summary['nmap_authorizations'] = authorizations
        summary['supplement_counts'] = {'pytest_tests': 1, 'architecture_subtests': 2, 'real_nmap_invocations': 4,
                                        'legacy_tests': 6, 'dom_tests': 4, 'browser_scenarios': 1}
        summary['status'] = 'passed'
    except BaseException as error:
        summary.update(status='failed', error=str(error))
        raise
    finally:
        after = inventory()
        write('source-after.json', after)
        summary['source_unchanged'] = before == after
        summary['source_inventory_sha256'] = sha(ROOT / 'source-before.json')
        summary['git_status_after'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True)
        summary['existing_panel_starttime_unchanged'] = panel_before.split()[21] == Path('/proc/34290/stat').read_text().split()[21]
        summary['existing_panel_not_stopped'] = Path('/proc/34290').exists()
        summary['finished_at'] = datetime.now(timezone.utc).isoformat()
        summary['commands'] = records
        summary['guards'] = {'browser_legacy_sha256': sha(guard / 'sitecustomize.py'),
                             'supplement_sha256': sha(supplement / 'sitecustomize.py')}
        summary['limits'] = ['No apt/systemctl/usermod, Docker/broker/laboratories, firewall, routes, namespaces or cgroups changed.',
                             'No OpenAI/LLM requests or costs; provider keys absent.',
                             'Nmap software integration uses localhost-only services and simulated authorization/runtime fixtures; it is not protected-bank acceptance.',
                             'Existing prototype venv reused; legacy venv and npm installation created from existing pinned caches.',
                             'No change to the deployed service or its account/data; only owned temporary backends started and stopped.']
        write('summary.json', summary)
        print(json.dumps({'status': summary['status'], 'source_unchanged': summary['source_unchanged'],
                          'summary': str(ROOT / 'summary.json')}), flush=True)
    assert summary['source_unchanged'] and summary['existing_panel_starttime_unchanged']
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
