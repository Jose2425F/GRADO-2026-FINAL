#!/usr/bin/env python3
"""Prepara un daemon Docker separado en una red sin salida para la aceptación 11.3.

No modifica el daemon principal: sólo enumera sus contenedores e imágenes y lee
sus capas mediante docker save. El daemon nuevo, su red, sus montajes y datos
quedan identificados por un nonce y se conservan para inspección.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import uuid

DOCKER='/usr/bin/docker'
MAIN='unix:///var/run/docker.sock'
IMAGES=['novaflow-lab-credentials:local','novaflow-lab-protocol:local',
        'novaflow-lab-http:local','auditoria-lab-v2-app:local','postgres:16-alpine']

def run(argv, **kw):
    return subprocess.run(argv,check=True,capture_output=True,text=True,**kw).stdout

def docker(host,*args):
    return run([DOCKER,'--host',host,*args],timeout=60)

def containers(host):
    result=[]
    for name in docker(host,'ps','-a','--format','{{.Names}}').splitlines():
        data=docker(host,'container','inspect','--format',
            '{"name":{{json .Name}},"id":{{json .Id}},"image":{{json .Image}},"status":{{json .State.Status}}}',name)
        result.append(json.loads(data))
    return sorted(result,key=lambda x:x['name'])

def private_json(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    path.chmod(0o600)

def copy_repo(source,target):
    paths=subprocess.check_output(['git','-C',str(source),'ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
    records=[]
    for name in sorted(set(paths)):
        if not name or name.startswith(('.git','work/')):continue
        p=source/name
        if not p.is_file() or p.is_symlink():continue
        if any(part.startswith(('.lab','.venv')) or part in {'__pycache__','node_modules','corridas','archivo_corridas'} for part in p.relative_to(source).parts):continue
        dest=target/name;dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dest);dest.chmod(0o555 if os.access(p,os.X_OK) else 0o444)
        records.append({'path':name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size})
    for p in sorted(target.rglob('*'),reverse=True):
        if p.is_dir():p.chmod(0o555)
    target.chmod(0o555)
    return records

def copy_venv(source,target,repo):
    shutil.copytree(source,target,symlinks=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    removed=[]
    for p in target.rglob('*.pth'):
        removed.append(str(p.relative_to(target)));p.unlink()
    package=target/'lib/python3.13/site-packages/auditoria'
    if package.exists() or package.is_symlink():
        if package.is_symlink() or package.is_file():package.unlink()
        else:shutil.rmtree(package)
    package.symlink_to(repo/'piloto_kali/prototipo/src/auditoria',target_is_directory=True)
    for p in (target/'bin').iterdir():
        if p.is_file() and not p.is_symlink():
            b=p.read_bytes()
            if b.startswith(b'#!') and b'python' in b.split(b'\n',1)[0]:
                p.write_bytes(b'#!'+str(target/'bin/python').encode()+b'\n'+b.split(b'\n',1)[1])
    for p in sorted(target.rglob('*'),reverse=True):
        if p.is_symlink():continue
        p.chmod(0o555 if p.is_dir() or os.access(p,os.X_OK) else 0o444)
    target.chmod(0o555)
    return removed

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--venv',type=Path,required=True)
    parser.add_argument('--evidence-dir',type=Path,required=True)
    args=parser.parse_args()
    if os.geteuid()!=0:parser.error('Ejecutar desde la consola del operador con sudo.')
    args.repo=args.repo.resolve();args.venv=args.venv.resolve()
    args.evidence_dir.mkdir(parents=True,exist_ok=True)
    uid=int(os.environ.get('SUDO_UID','1000'));gid=int(os.environ.get('SUDO_GID','1002'))
    nonce=uuid.uuid4().hex[:12];ns='c113-'+nonce
    root=Path('/var/tmp')/ns
    root.mkdir(mode=0o755)
    state=root/'private';state.mkdir(mode=0o700)
    code=root/'repo';code.mkdir(mode=0o755)
    artifacts=root/'artifacts';artifacts.mkdir(mode=0o700);os.chown(artifacts,uid,gid)
    before=containers(MAIN)
    image_map={name:docker(MAIN,'image','inspect','--format','{{.Id}}',name).strip() for name in IMAGES}
    assert all(re.fullmatch('sha256:[0-9a-f]{64}',x) for x in image_map.values())
    source_receipt=copy_repo(args.repo,code)
    removed=copy_venv(args.venv,root/'venv',code)
    # The worktree's .venv entry is root-controlled and points only to the protected copy.
    (code/'piloto_kali/prototipo').chmod(0o755)
    (code/'piloto_kali/prototipo/.venv').symlink_to(root/'venv',target_is_directory=True)
    (code/'piloto_kali/prototipo').chmod(0o555)
    run(['/usr/sbin/ip','netns','add',ns])
    run(['/usr/sbin/ip','-n',ns,'link','set','lo','up'])
    host='unix://'+str(state/'docker.sock')
    daemon=['/usr/sbin/dockerd','--data-root',str(state/'docker-data'),'--exec-root',str(state/'exec'),
        '--pidfile',str(state/'dockerd.pid'),'--host',host,'--bridge','none',
        '--iptables=false','--ip6tables=false','--ip-forward=false','--ip-masq=false',
        '--userland-proxy=false','--containerd',str(state/'containerd.sock'),
        '--containerd-namespace',ns,'--containerd-plugins-namespace',ns+'p',
        '--exec-opt','native.cgroupdriver=cgroupfs','--cgroup-parent','/'+ns]
    # ip netns exec remounts /sys for the selected network namespace. Re-mount
    # cgroup2 only in a private mount namespace, and use a separate containerd.
    supervisor=state/'daemon-supervisor.py'
    config={'state':str(state),'daemon':daemon,'namespace':ns}
    private_json(state/'daemon-config.json',config)
    supervisor.write_text('''import json, pathlib, signal, subprocess, sys, time
root=pathlib.Path(sys.argv[1]);config=json.loads((root/'daemon-config.json').read_text())
subprocess.run(['/usr/bin/mount','-t','cgroup2','none','/sys/fs/cgroup'],check=True)
(root/'containerd.toml').write_text('version = 2\\ndisabled_plugins = ["io.containerd.grpc.v1.cri"]\\n')
stream=(root/'containerd.log').open('wb')
containerd=subprocess.Popen(['/usr/bin/containerd','--config',str(root/'containerd.toml'),
    '--root',str(root/'containerd-data'),'--state',str(root/'containerd-state'),
    '--address',str(root/'containerd.sock')],stdout=stream,stderr=subprocess.STDOUT)
deadline=time.monotonic()+20
while not (root/'containerd.sock').exists():
    if containerd.poll() is not None or time.monotonic()>deadline:raise RuntimeError('private containerd unavailable')
    time.sleep(.1)
daemon=subprocess.Popen(config['daemon'])
(root/'child-pids.json').write_text(json.dumps({'containerd':containerd.pid,'dockerd':daemon.pid}))
def stop(*args):
    for process in [daemon,containerd]:
        if process.poll() is None:process.terminate()
    for process in [daemon,containerd]:
        try:process.wait(timeout=20)
        except subprocess.TimeoutExpired:process.kill();process.wait()
    sys.exit(0)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
try:
    code=daemon.wait()
finally:
    if containerd.poll() is None:containerd.terminate();containerd.wait(timeout=20)
sys.exit(code)
''')
    supervisor.chmod(0o600)
    argv=['/usr/sbin/ip','netns','exec',ns,'/usr/bin/unshare','--mount','--propagation','private',
        '/usr/bin/python3','-I',str(supervisor),str(state)]
    log=(state/'dockerd.log').open('wb')
    proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    metadata={'schema':'centinela-isolated-bootstrap/1','created_at':datetime.now(timezone.utc).isoformat(),
        'namespace':ns,'root':str(root),'docker_host':host,'supervisor_pid':proc.pid,'daemon_command':daemon,
        'operator_uid':0,'audit_uid':uid,'audit_gid':gid,'source_repo':str(args.repo),
        'protected_repo':str(code),'protected_venv':str(root/'venv'),'removed_pth':removed,
        'main_containers_before':before,'images':image_map,'containers_created':False,
        'no_compose_started':True,'no_host_firewall_changes':True}
    private_json(state/'bootstrap.json',metadata)
    deadline=time.monotonic()+45
    while True:
        if proc.poll() is not None:
            raise RuntimeError('Daemon aislado terminó: '+str(state/'dockerd.log'))
        try:
            metadata['daemon_version']=docker(host,'version','--format','{{.Server.Version}}').strip();break
        except subprocess.SubprocessError:
            if time.monotonic()>=deadline:raise RuntimeError('Timeout al iniciar daemon aislado')
            time.sleep(.3)
    routes=json.loads(run(['/usr/sbin/ip','-n',ns,'-j','route','show','table','all']))
    routes6=json.loads(run(['/usr/sbin/ip','-n',ns,'-j','-6','route','show','table','all']))
    assert not any(x.get('dst')=='default' for x in routes+routes6)
    metadata['initial_routes']={'ipv4':routes,'ipv6':routes6}
    metadata['network_namespace_inode']=os.stat('/run/netns/'+ns).st_ino
    # Stream pinned local images into the new daemon; no download, pull or build.
    with (state/'image-load.log').open('wb') as load_log,(state/'image-save.log').open('wb') as save_log:
        saving=subprocess.Popen([DOCKER,'--host',MAIN,'image','save',*sorted(set(image_map.values()))],
            stdout=subprocess.PIPE,stderr=save_log)
        loading=subprocess.Popen([DOCKER,'--host',host,'image','load'],stdin=subprocess.PIPE,
            stdout=load_log,stderr=subprocess.STDOUT)
        digest=hashlib.sha256();total=0
        try:
            while True:
                chunk=saving.stdout.read(1024*1024)
                if not chunk:break
                digest.update(chunk);total+=len(chunk);loading.stdin.write(chunk)
            loading.stdin.close();saving.stdout.close()
            save_code=saving.wait(timeout=60);load_code=loading.wait(timeout=120)
            if save_code or load_code:raise RuntimeError('Error al cargar las imágenes locales fijadas')
        finally:
            for process in [saving,loading]:
                if process.poll() is None:process.kill();process.wait()
    for name,image in image_map.items():
        docker(host,'image','tag',image,name)
        assert docker(host,'image','inspect','--format','{{.Id}}',name).strip()==image
    after=containers(MAIN)
    assert before==after,'Cambió la identidad/estado de un contenedor del daemon original'
    assert not containers(host)
    metadata.update({'image_archive_sha256':digest.hexdigest(),'image_archive_bytes':total,
        'main_containers_after':after,'main_containers_unchanged':True,'isolated_containers':[],
        'no_external_default_route':True,'images_loaded_and_pinned':True})
    metadata.update(json.loads((state/'child-pids.json').read_text()))
    private_json(state/'bootstrap.json',metadata)
    private_json(state/'source-hashes.json',source_receipt)
    # Public receipt contains no environment variables, account keys or fixture passwords.
    out=args.evidence_dir/'bootstrap-aislado.json';out.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n');out.chmod(0o644)
    os.chown(out,uid,gid)
    print(json.dumps({'ready':True,'namespace':ns,'root':str(root),'docker_host':host,
        'receipt':str(out),'images':len(image_map),'original_containers_unchanged':len(before)},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
