#!/usr/bin/env python3
"""Publica copias de resultados y bitácoras, sin políticas ni estado reservado."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat


def safe(path):
    path=Path(path)
    for current in [path,*path.parents]:
        info=current.lstat()
        sticky=current!=path and info.st_uid==0 and stat.S_ISDIR(info.st_mode) and info.st_mode&stat.S_ISVTX
        if current.is_symlink() or info.st_uid!=0 or info.st_mode&0o022 and not sticky:raise ValueError('Fuente no protegida: '+str(current))
    return path


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--base',type=Path,required=True);parser.add_argument('--run',required=True)
    args=parser.parse_args();base=args.base
    if os.geteuid()!=0 or base.parent!=Path('/var/tmp') or not re.fullmatch('c113-[0-9a-f]{12}',base.name):parser.error('Sólo operador y stage c113.')
    if not re.fullmatch(r'[0-9]{8}T[0-9]{6}Z-(?:integrado|sucursal|comercial|mixto|reforzado)-[0-9a-f]{8}',args.run):parser.error('Identificador no admitido.')
    safe(base);private=safe(base/'private'/args.run);receipt=safe(private/'operator.json');data=json.loads(receipt.read_text())
    if data['status'] in {'running','preparing'}:raise ValueError('No se exporta una ejecución activa.')
    public=base/'public'
    if public.exists():safe(public)
    else:public.mkdir(mode=0o755)
    target=public/args.run
    if target.exists():raise ValueError('La copia pública ya existe; no se sobrescribe.')
    target.mkdir(mode=0o755)
    secrets=[]
    for state in [base/'repo/piloto_kali/prototipo/.lab-empresa',*(base/'repo/piloto_kali/prototipo/.lab-suite').glob('*')]:
        env=state/'lab.env'
        if env.is_file():
            for line in safe(env).read_text().splitlines():
                if '=' in line:
                    value=line.split('=',1)[1].encode()
                    if len(value)>=8:secrets.extend([value,base64.b64encode(value)])
    files={}
    def emit(relative,raw):
        if any(value in raw for value in secrets):raise ValueError('Se detectó un secreto sintético en: '+str(relative))
        path=target/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);path.chmod(0o444)
        files[str(relative)]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
    keys=['version','run_id','bank','created_at_utc','status','roles','api_calls','original_daemon_mutations','attempts','operator_identity',
          'controller_identity','nmap_identity','hydra_identity','broker_identity','failure','ended_at_utc','tool_installation',
          'descriptor_sha256','catalogue_tasks','broker_policy_sha256','role_negative_checks','origin_filter_checks',
          'controller_exit_code','operator_exit_code','operator_evaluation','operator_evaluation_error','roles_stopped_before_evaluation',
          'persistent_segment_lock_root','cleanup_errors']
    projection={key:data[key] for key in keys if key in data}
    projection['private_original_operator_sha256']=hashlib.sha256(receipt.read_bytes()).hexdigest()
    emit(Path('operator-public.json'),(json.dumps(projection,ensure_ascii=False,indent=2)+'\n').encode())
    for name in ['broker-stdout.log','controller-stdout.log','nmap-stdout.log','hydra-stdout.log','broker-audit.jsonl','refresh.jsonl','role-negative-operator.json','evaluation-operador.json']:
        path=private/name
        if path.is_file():emit(Path('operator')/name,safe(path).read_bytes())
    runtime=safe(base/'runtime'/args.run)
    for role in ['nmap','hydra']:
        path=runtime/role/'audit.jsonl'
        if path.is_file():
            safe(path.parent);descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
            try:
                info=os.fstat(descriptor)
                if (not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_uid!={'nmap':65532,'hydra':65533}[role]
                        or info.st_size>8_000_000):raise ValueError('Bitácora de trabajador inválida.')
                with os.fdopen(descriptor,'rb',closefd=False) as stream:raw=stream.read(8_000_001)
            finally:os.close(descriptor)
            if len(raw)!=info.st_size:raise ValueError('La bitácora del trabajador cambió.')
            emit(Path('operator')/(role+'-audit.jsonl'),raw)
    snapshot=private/'evaluation-snapshot'
    if snapshot.exists():
        safe(snapshot)
        for path in sorted(snapshot.rglob('*')):
            if path.is_file():
                safe(path)
                if path.suffix not in {'.json','.txt','.xml','.pcap','.pcapng','.sqlite3'}:raise ValueError('Extensión no admitida.')
                emit(Path('controller')/path.relative_to(snapshot),path.read_bytes())
    proof=private/'origin-filter-proof'
    if proof.exists():
        for path in sorted(proof.iterdir()):
            if path.is_file():emit(Path('origin-filter-proof')/path.name,safe(path).read_bytes())
    manifest={'schema':'centinela-public-run-copy/1','run_id':args.run,'bank':data['bank'],'status':data['status'],
        'copy_only_originals_preserved':True,'excluded':['broker and worker policies','lab.env','ground_truth.json','state directories','Docker data'],
        'exact_fixture_secrets_scan_passed':True,'files':files}
    (target/'manifest-public.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');(target/'manifest-public.json').chmod(0o444)
    for path in sorted(target.rglob('*'),reverse=True):
        if path.is_dir():path.chmod(0o555)
    target.chmod(0o555);print(json.dumps({'public':str(target),'files':len(files),'status':data['status']}))


if __name__=='__main__':main()
