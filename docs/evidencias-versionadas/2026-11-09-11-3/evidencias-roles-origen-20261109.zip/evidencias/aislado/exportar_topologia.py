#!/usr/bin/env python3
"""Proyección de topología del daemon aislado; no ejecuta adaptadores ni sondas."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import stat
import subprocess

COUNTS={'integrado':12,'sucursal':8,'comercial':10,'mixto':12,'reforzado':14}
PREFIX={'integrado':'nova','sucursal':'nf1','comercial':'nf2','mixto':'nf3','reforzado':'nf4'}
NETS={'integrado':['nova_dmz','nova_corp','nova_datacenter'],**{name:[prefix+'_dmz',prefix+'_corp',prefix+'_dc'] for name,prefix in PREFIX.items() if name!='integrado'}}
FIELDS=['Name','Uid','Gid','Groups','CapInh','CapPrm','CapEff','CapBnd','CapAmb','NoNewPrivs','Seccomp']

def run(argv):return subprocess.check_output(argv,text=True,timeout=30)

def proc_status(pid):
    fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line}
    return {key:fields.get(key) for key in FIELDS}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base',type=Path,required=True)
    parser.add_argument('--public-dir',type=Path)
    args=parser.parse_args();base=args.base
    if os.geteuid()!=0:parser.error('Sólo operador root')
    if base.parent!=Path('/var/tmp') or not re.fullmatch('c113-[0-9a-f]{12}',base.name) or base.is_symlink():parser.error('Stage no admitido')
    info=base.stat()
    if info.st_uid!=0 or info.st_mode&0o022:parser.error('Stage modificable por terceros')
    private=base/'private';manifest=json.loads((private/'bootstrap.json').read_text())
    ns=manifest['namespace'];host=manifest['docker_host']
    assert ns==base.name and host=='unix://'+str(private/'docker.sock')
    def docker(*argv):return run(['/usr/bin/docker','--host',host,*argv])
    links=json.loads(run(['/usr/sbin/ip','-n',ns,'-j','link','show']))
    addresses=json.loads(run(['/usr/sbin/ip','-n',ns,'-j','addr','show']))
    byindex={row['ifindex']:row for row in links}
    names=docker('ps','-a','--format','{{.Names}}').splitlines()
    assert len(names)==sum(COUNTS.values())
    rows=[]
    for name in names:
        assert re.fullmatch(r'(?:nova|nf[1-4])-[a-z0-9-]+',name)
        template='{"name":{{json .Name}},"id":{{json .Id}},"image":{{json .Image}},"pid":{{json .State.Pid}},"running":{{json .State.Running}},"configured_user":{{json .Config.User}},"labels":{{json .Config.Labels}},"cap_add":{{json .HostConfig.CapAdd}},"cap_drop":{{json .HostConfig.CapDrop}},"privileged":{{json .HostConfig.Privileged}},"security_opt":{{json .HostConfig.SecurityOpt}},"readonly_rootfs":{{json .HostConfig.ReadonlyRootfs}},"networks":{{json .NetworkSettings.Networks}}}'
        item=json.loads(docker('container','inspect','--format',template,name));assert item['running']
        pid=item['pid'];item['effective_process']=proc_status(pid)
        item['network_namespace_inode']=os.stat(f'/proc/{pid}/ns/net').st_ino
        item['links']=json.loads(run(['/usr/bin/nsenter','--target',str(pid),'--net','/usr/sbin/ip','-j','link','show']))
        item['addresses']=json.loads(run(['/usr/bin/nsenter','--target',str(pid),'--net','/usr/sbin/ip','-j','addr','show']))
        item['host_veths']=[byindex[link['link_index']] for link in item['links'] if link['ifname']!='lo' and link.get('link_index') in byindex]
        rows.append(item)
    records=[]
    for scenario,prefix in PREFIX.items():
        chosen=sorted([item for item in rows if item['name'].startswith('/'+prefix+'-')],key=lambda x:x['name'])
        assert len(chosen)==COUNTS[scenario]
        networks=[]
        for name in NETS[scenario]:
            template='{"name":{{json .Name}},"id":{{json .Id}},"internal":{{json .Internal}},"ipv6":{{json .EnableIPv6}},"ipam":{{json .IPAM.Config}},"options":{{json .Options}},"labels":{{json .Labels}},"containers":{{json .Containers}}}'
            networks.append(json.loads(docker('network','inspect','--format',template,name)))
        bridge_names={x['options']['com.docker.network.bridge.name'] for x in networks}
        record={'schema':'centinela-isolated-topology/2','captured_at_utc':datetime.now(timezone.utc).isoformat(),'scenario':scenario,'namespace':ns,'docker_host':host,
            'containers':chosen,'networks':networks,'namespace_links':links,'namespace_addresses':addresses,
            'host_bridge_addresses':[a for a in addresses if a['ifname'] in bridge_names],
            'namespace_routes4':json.loads(run(['/usr/sbin/ip','-n',ns,'-j','route','show','table','all'])),
            'namespace_routes6':json.loads(run(['/usr/sbin/ip','-n',ns,'-j','-6','route','show','table','all'])),
            'this_capture_executes_audit_adapters':False,'scope':'Read-only topology capture; this file does not establish privilege or firewall acceptance.'}
        filename='topologia-'+scenario+'.json';content=json.dumps(record,ensure_ascii=False,indent=2)+'\n'
        (private/filename).write_text(content);(private/filename).chmod(0o600)
        if args.public_dir:
            target=args.public_dir/filename;target.write_text(content);target.chmod(0o644)
            os.chown(target,int(os.environ.get('SUDO_UID','1000')),int(os.environ.get('SUDO_GID','1002')))
        records.append({'scenario':scenario,'containers':len(chosen),'private_topology':str(private/filename)})
    result={'namespace':ns,'banks':records,'total_containers':len(rows),'infrastructure_roles':
        {name:{'pid':pid,'status':proc_status(pid),'role':'privileged isolated Docker infrastructure; not audit agent'}
         for name,pid in json.loads((private/'child-pids.json').read_text()).items()}}
    (private/'topologias-cinco-bancos.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(private/'topologias-cinco-bancos.json').chmod(0o600)
    if args.public_dir:
        target=args.public_dir/'topologias-cinco-bancos.json';target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');target.chmod(0o644)
        os.chown(target,int(os.environ.get('SUDO_UID','1000')),int(os.environ.get('SUDO_GID','1002')))
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
