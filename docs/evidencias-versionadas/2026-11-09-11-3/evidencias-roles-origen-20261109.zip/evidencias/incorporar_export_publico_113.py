#!/usr/bin/env python3
"""Añade una exportación pública cerrada y explícitamente indicada al borrador."""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re

BASE=Path(__file__).resolve().parent
PUBLIC=Path('/var/tmp/c113-9d49e066fefb/public')
EXPECTED={'integrado':32,'sucursal':25,'comercial':28,'mixto':32,'reforzado':37}


def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')


def attach(bank,run,*,supplementary=False):
    if not re.fullmatch(r'20261109T[0-9]{6}Z-'+bank+r'-[a-f0-9]{8}',run):raise ValueError('run_id no admitido')
    root=PUBLIC/run
    operator=json.loads((root/'operator-public.json').read_text());evaluation=operator['operator_evaluation']
    reports=list(root.rglob('report.json'))
    if len(reports)!=1:raise ValueError('Se esperaba un informe único')
    report=json.loads(reports[0].read_text())
    architecture='multiagent' if supplementary else 'single'
    if report.get('architecture')!=architecture or (supplementary and bank!='integrado'):
        raise ValueError('Arquitectura o banco distintos del tipo de evidencia solicitado.')
    if (operator.get('status')!='finished' or operator.get('operator_exit_code')!=0 or operator.get('cleanup_errors')
        or operator.get('roles_stopped_before_evaluation') is not True
        or evaluation.get('acceptance_passed') is not True or evaluation.get('evidence_valid') is not True
        or evaluation.get('tasks_valid')!=EXPECTED[bank] or len(report['tasks'])!=EXPECTED[bank]
        or evaluation.get('FP')!=0 or evaluation.get('FN')!=0):raise ValueError('El banco no tiene aceptación final válida')
    descriptor_path=PUBLIC/'provenance'/run/'descriptor.json';descriptor_raw=descriptor_path.read_bytes()
    if hashlib.sha256(descriptor_raw).hexdigest()!=operator['descriptor_sha256']:raise ValueError('Descriptor distinto del recibo')
    descriptor=json.loads(descriptor_raw)
    checks=[]
    for name,pin in descriptor['source_hashes'].items():
        relative=Path(name).relative_to('/var/tmp/c113-9d49e066fefb/repo')
        if '..' in relative.parts:raise ValueError('Ruta de fuente inválida')
        current=BASE/'repo'/relative
        checks.append({'path':str(relative),'sha256':pin,'matched':current.is_file() and hashlib.sha256(current.read_bytes()).hexdigest()==pin,
            'kind':'test_auxiliary' if '/tests/' in '/'+str(relative) else 'runtime_source'})
    if not all(row['matched'] for row in checks if row['kind']=='runtime_source'):raise ValueError('Cambió fuente de ejecución')
    config_path=BASE/'fuentes-publicacion-113.json';config=json.loads(config_path.read_text());known={row['source'] for row in config['entries']}
    for path in sorted(root.rglob('*')):
        if path.is_file() and str(path) not in known:
            config['entries'].append({'source':str(path),'entry':'evidencias/aceptacion-publica/'+run+'/'+str(path.relative_to(root)),
                'classification':'supplementary_multiagent' if supplementary else 'runtime_final','note':('Suplemento Multiagent separado de las154 canónicas: ' if supplementary else 'Aceptación final de '+bank+': ')+str(EXPECTED[bank])+' tareas válidas, salida 0 y evidencia aprobada; no se suma a los KPI históricos.'})
    if str(descriptor_path) not in known:
        config['entries'].append({'source':str(descriptor_path),'entry':'evidencias/aceptacion-publica/provenance/'+run+'/descriptor.json',
            'classification':'runtime_final','note':'Descriptor público cotejado con su recibo; fuentes de ejecución sin cambios.'})
    save(config_path,config)
    folder=BASE/'repo/docs/evidencias-versionadas/2026-11-09-11-3'
    summary_path=folder/'resumen-validacion.json';summary=json.loads(summary_path.read_text());banks=summary['catalogue_final_accepted']
    record={'run_id':run,'tasks':EXPECTED[bank],'statuses':dict(collections.Counter(row['status'] for row in report['tasks'])),
        'report_status':report['status'],'architecture':report['architecture'],'accepted':True,
        **{key:evaluation[key] for key in ['TP','FP','FN','TN']},'source':'evidencias/aceptacion-publica/'+run}
    if supplementary:
        summary['supplementary_multiagent']=record|{'scope':'integrado_multiagent_no_api_supplement','replaces_canonical_integrated_single':False}
    else:
        if bank in banks and banks[bank]['run_id']!=run:raise ValueError('La aceptación canónica ya tiene otro run_id; no se reemplaza.')
        banks[bank]=record
    banks['accepted_task_count']=sum(banks[name]['tasks'] for name in EXPECTED if name in banks)
    banks['pending_banks']=[name for name in EXPECTED if name not in banks]
    save(summary_path,summary)
    provenance_path=folder/'procedencia-codigo.json';provenance=json.loads(provenance_path.read_text())
    records=[row for row in provenance.get('other_runtime_manifests',[]) if row['run_id']!=run]
    records.append({'run_id':run,'descriptor_sha256':hashlib.sha256(descriptor_raw).hexdigest(),
        'receipt_descriptor_sha256':operator['descriptor_sha256'],'descriptor_matches_receipt':True,
        'runtime_sources_all_matched':True,'checks':checks})
    provenance['other_runtime_manifests']=records;save(provenance_path,provenance)
    print(json.dumps({'bank':bank,'run_id':run,'accepted_tasks':EXPECTED[bank],
        'final_valid_task_count_so_far':banks['accepted_task_count'],'pending':banks['pending_banks'],'supplementary_multiagent':supplementary}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--bank',choices=list(EXPECTED),required=True)
    parser.add_argument('--run-id',required=True);parser.add_argument('--supplementary-multiagent',action='store_true')
    args=parser.parse_args();attach(args.bank,args.run_id,supplementary=args.supplementary_multiagent)
