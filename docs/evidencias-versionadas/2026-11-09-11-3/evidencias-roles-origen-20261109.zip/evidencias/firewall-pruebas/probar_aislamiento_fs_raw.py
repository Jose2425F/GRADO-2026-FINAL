import json,os,socket
from pathlib import Path
results=[]
def attempt(name,operation):
 r={'name':name,'content_read':False}
 try:
  value=operation()
  if hasattr(value,'close'):value.close()
  else:os.close(value)
  r['unexpected_success']=True;r['passed']=False
 except OSError as e:r.update(error=type(e).__name__,errno=e.errno,passed=isinstance(e,PermissionError))
 results.append(r)
def daemon():
 s=socket.socket(socket.AF_UNIX);s.settimeout(1)
 try:s.connect('/var/tmp/c113-9d49e066fefb/private/docker.sock')
 except BaseException:s.close();raise
 return s
attempt('controller_direct_docker_socket',daemon)
attempt('controller_github_hosts_open_without_read',lambda:os.open('/home/kali/.config/gh/hosts.yml',os.O_RDONLY|os.O_NOFOLLOW))
attempt('controller_AF_PACKET_RAW',lambda:socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.htons(3)))
attempt('controller_AF_PACKET_DGRAM',lambda:socket.socket(socket.AF_PACKET,socket.SOCK_DGRAM,socket.htons(3)))
attempt('controller_AF_INET6_RAW',lambda:socket.socket(socket.AF_INET6,socket.SOCK_RAW,socket.IPPROTO_ICMPV6))
fields={k:v.strip() for k,v in (line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines()) if k in {'Uid','Gid','Groups','CapInh','CapPrm','CapEff','CapBnd','CapAmb','NoNewPrivs'}}
print(json.dumps({'identity':fields,'pid':os.getpid(),'namespace':os.readlink('/proc/self/ns/net'),'results':results,'passed':all(r['passed'] for r in results),'content_bytes_read':0}))
