#!/usr/bin/env python3
"""Empaqueta exclusivamente archivos aprobados; no descubre ni lee estado privado."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import stat
import subprocess
import zipfile

KEY_PATTERNS=[re.compile(rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}'),
              re.compile(rb'AKIA[0-9A-Z]{16}'),re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')]
ALLOWED_ENV={'LAB_FIXTURE_SEED','LAB_SCENARIO','LAB_GUARDED'}
FORBIDDEN_NAMES={'lab.env','.env','openai.json','credentials.json','accounts.json','sessions.json'}
HISTORICAL_PREFIXES=['docs/evidencias-versionadas/','docs/ajustes-profesor/',
    'docs/evidencias-historicas/','docs/evaluacion-langgraph/','docs/entregas/']

def digest(data):return hashlib.sha256(data).hexdigest()

def write(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,sort_keys=True)+'\n')

def protected_source(path):
    path=Path(path)
    if not path.is_absolute() or any(part.lower()=='private' or part.lower() in FORBIDDEN_NAMES for part in path.parts):
        raise ValueError('Fuente privada o no admitida: '+str(path))
    for part in [path,*path.parents]:
        if part.is_symlink():raise ValueError('Enlace de fuente no admitido: '+str(path))
    info=path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_size>25_000_000:
        raise ValueError('Fuente no regular o fuera de límite: '+str(path))
    return path,info

def json_review(value):
    if isinstance(value,dict):
        for key,item in value.items():
            lower=key.lower()
            if lower in {'api_key','openai_api_key','access_token','refresh_token','private_key','password'} and item not in [None,'','<redacted>']:
                raise ValueError('Campo privado no publicable: '+key)
            if lower=='env':
                if not isinstance(item,list) or any(not isinstance(x,str) or x.partition('=')[0] not in ALLOWED_ENV for x in item):
                    raise ValueError('Entorno Docker no publicable')
            json_review(item)
    elif isinstance(value,list):
        for item in value:json_review(item)

def scan(path,data,allowed_fixtures):
    findings=[]
    for pattern in KEY_PATTERNS:
        for match in pattern.finditer(data):
            value=digest(match.group())
            if value not in allowed_fixtures:findings.append({'pattern':pattern.pattern.decode(),'sha256':value,'offset':match.start()})
    if findings:raise ValueError('Patrón privado requiere revisión (sin mostrar contenido): '+json.dumps({'source':str(path),'findings':findings}))
    if path.suffix=='.json':json_review(json.loads(data))

def verify_public_exports(entries):
    approved={str(Path(row['source'])) for row in entries}
    checked=[]
    for row in entries:
        path=Path(row['source'])
        if path.name!='manifest-public.json':continue
        manifest=json.loads(path.read_text())
        if manifest.get('exact_fixture_secrets_scan_passed') is not True:
            raise ValueError('Exportación sin revisión privada aprobada: '+str(path))
        for name,pin in manifest['files'].items():
            relative=PurePosixPath(name)
            if relative.is_absolute() or '..' in relative.parts:raise ValueError('Ruta de exportación inválida')
            source=path.parent/relative
            if str(source) not in approved:raise ValueError('Falta archivo de la exportación aprobada: '+str(source))
            source,info=protected_source(source);raw=source.read_bytes()
            if len(raw)!=pin['bytes'] or digest(raw)!=pin['sha256']:
                raise ValueError('La copia pública no coincide con su manifiesto: '+str(source))
        checked.append({'source':str(path),'run_id':manifest['run_id'],'files':len(manifest['files']),'verified':True})
    return checked


def conservation(repo,revisions):
    result={'schema':'centinela-historical-conservation/1','checked_at_utc':datetime.now(timezone.utc).isoformat(),
            'scope':HISTORICAL_PREFIXES,'revisions':[],'all_previous_files_preserved':True}
    for revision in revisions:
        commit=subprocess.check_output(['git','rev-parse',revision+'^{commit}'],cwd=repo,text=True).strip()
        tree=subprocess.check_output(['git','ls-tree','-r','-z',commit,'--',*[x.rstrip('/') for x in HISTORICAL_PREFIXES]],cwd=repo)
        files=[]
        for record in tree.split(b'\0'):
            if not record:continue
            meta,encoded=record.split(b'\t',1);mode,kind,oid=meta.decode().split();name=encoded.decode()
            if kind!='blob':raise ValueError('Entrada histórica no regular: '+name)
            old=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo)
            current=repo/name
            okay=current.is_file() and not current.is_symlink() and current.read_bytes()==old
            files.append({'path':name,'git_blob':oid,'bytes':len(old),'sha256':digest(old),'unchanged':okay})
        if not all(item['unchanged'] for item in files):result['all_previous_files_preserved']=False
        result['revisions'].append({'commit':commit,'files':files,'count':len(files)})
    if result['all_previous_files_preserved'] is not True:raise ValueError('Una evidencia anterior cambió o falta.')
    return result

def pack(config_path):
    config=json.loads(Path(config_path).read_text())
    repo=Path(config['repository']);destination=repo/config['destination']
    if destination!=repo/'docs/evidencias-versionadas/2026-11-09-11-3':raise ValueError('Destino ajeno a esta versión')
    destination.mkdir(parents=True,exist_ok=True)
    allowed=set(config.get('approved_fictitious_token_sha256',[]));entries=[];content={}
    for row in config['entries']:
        if set(row)!={'source','entry','classification','note'}:raise ValueError('Aprobación incompleta')
        path,info=protected_source(row['source']);entry=PurePosixPath(row['entry'])
        if entry.is_absolute() or '..' in entry.parts or str(entry)!=row['entry'] or entry.parts[0]!='evidencias':raise ValueError('Ruta ZIP inválida')
        if str(entry) in content:raise ValueError('Entrada ZIP duplicada')
        data=path.read_bytes();after=path.stat()
        if (info.st_ino,info.st_size,info.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):raise ValueError('Fuente aún cambia: '+str(path))
        scan(path,data,allowed);content[str(entry)]=data
        entries.append(row|{'bytes':len(data),'sha256':digest(data),'source_mtime_ns':info.st_mtime_ns,'byte_identical_copy':True})
    public_exports=verify_public_exports(entries)
    historical=conservation(repo,config.get('historical_revisions',['bc7f7d5','b579f49']))
    write(destination/'conservacion-historica.json',historical)
    zip_path=destination/'evidencias-roles-origen-20261109.zip'
    with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(content.items()):
            item=zipfile.ZipInfo(name,(2026,11,9,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16
            archive.writestr(item,data)
    manifest={'schema':'centinela-evidence-entries/1','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'status':config['status'],'scope':'roles_origen_11_3_not_historical_kpi',
        'archive':zip_path.name,'archive_bytes':zip_path.stat().st_size,'archive_sha256':digest(zip_path.read_bytes()),
        'entry_count':len(entries),'entries':entries,'public_exports_verified':public_exports,
        'privacy_review':{'explicit_allowlist_only':True,'private_sources_excluded':True,
            'configured_keys_not_read':True,'fictitious_token_sha256_approved':sorted(allowed),
            'note':'Búsqueda por patrones y campos conocidos; no garantiza detectar cualquier secreto desconocido.'}}
    write(destination/'integridad-evidencias.json',manifest)
    approved_path=destination/'fuentes-aprobadas.json'
    write(approved_path,{'schema':'centinela-explicit-publication-allowlist/1','entries':config['entries'],
        'status':config['status'],'approved_fictitious_token_sha256':sorted(allowed)})
    publication=[]
    for path in sorted(destination.iterdir()):
        if path.name=='integridad-publicacion.json' or not path.is_file():continue
        data=path.read_bytes();publication.append({'path':path.name,'bytes':len(data),'sha256':digest(data)})
    adjustment=repo/'docs/ajustes-profesor/2026-11-09-roles-origen'
    for path in sorted(adjustment.iterdir()):
        if path.is_file():
            data=path.read_bytes();publication.append({'path':'../../ajustes-profesor/2026-11-09-roles-origen/'+path.name,
                'bytes':len(data),'sha256':digest(data)})
    write(destination/'integridad-publicacion.json',{'schema':'centinela-publication-integrity/1','files':publication})
    print(json.dumps({'archive':str(zip_path),'entries':len(entries),'archive_bytes':zip_path.stat().st_size,
        'historical_files':[x['count'] for x in historical['revisions']],'status':config['status']}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,required=True)
    pack(parser.parse_args().config)
